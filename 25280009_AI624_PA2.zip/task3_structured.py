"""
Task 3: Structured (Channel) Pruning using regression-based method (He et al., 2017).
Uses the SAME pretrained checkpoint as Tasks 0 and 1.

Pruning is done layer-by-layer starting from layer1. We prune OUTPUT channels of
conv layers, which reduces input channels of the NEXT conv layer. BatchNorm and
shortcut connections are adjusted accordingly.
"""
import os
import sys
import copy
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import OrderedDict
from sklearn.linear_model import Lasso

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import (
    DEVICE, BATCH_SIZE, TARGET_SPARSITY, ASSETS,
    load_pretrained_resnet18, get_dataloaders, get_eligible_layers,
    evaluate, profile_model, count_parameters, get_model_size_mb,
    train_one_epoch, save_results, load_results
)

os.makedirs(ASSETS, exist_ok=True)

# ─── Helpers ──────────────────────────────────────────────────────────
def get_module(model, name):
    parts = name.split('.')
    m = model
    for p in parts:
        m = getattr(m, p)
    return m

def set_module(model, name, new_mod):
    parts = name.split('.')
    parent = model
    for p in parts[:-1]:
        parent = getattr(parent, p)
    setattr(parent, parts[-1], new_mod)

# ─── Collect activations ─────────────────────────────────────────────
def collect_activations(model, layer_name, dataloader, device=DEVICE):
    inputs_list = []
    outputs_list = []
    def hook(module, inp, out):
        inputs_list.append(inp[0].detach().cpu())
        outputs_list.append(out.detach().cpu())
    handle = get_module(model, layer_name).register_forward_hook(hook)
    model.eval()
    with torch.no_grad():
        for images, _ in dataloader:
            model(images.to(device))
    handle.remove()
    return torch.cat(inputs_list, 0), torch.cat(outputs_list, 0)

# ─── Channel selection + weight reconstruction for one layer ─────────
def channel_prune_layer(weight, X, num_keep, padding, stride):
    """
    Prune input channels of a conv layer via LASSO + least-squares reconstruction.
    weight: (out_ch, in_ch, kh, kw)  -- the current conv weight
    X:      (N, in_ch, h, w)         -- calibration input activations
    Returns new_weight (out_ch, num_keep, kh, kw), kept_channel_indices
    """
    out_ch, in_ch, kh, kw = weight.shape
    N = X.shape[0]

    X_unf = F.unfold(X, kernel_size=(kh, kw), padding=padding, stride=stride)
    L = X_unf.shape[2]
    X_unf = X_unf.permute(0, 2, 1).reshape(N * L, in_ch * kh * kw)
    W_mat = weight.reshape(out_ch, in_ch * kh * kw).T
    Y = X_unf @ W_mat

    Z_list = []
    for i in range(in_ch):
        Xi = X_unf[:, i*kh*kw : (i+1)*kh*kw]
        Wi = weight[:, i, :, :].reshape(out_ch, kh*kw)
        Zi = Xi @ Wi.T
        Z_list.append(Zi)

    Z_stacked = torch.stack(Z_list, dim=1)
    Y_flat = Y.reshape(-1).numpy()
    Z_flat = Z_stacked.reshape(-1, in_ch).numpy()

    max_samples = 50000
    if Z_flat.shape[0] > max_samples:
        idx = np.random.choice(Z_flat.shape[0], max_samples, replace=False)
        Z_sub, Y_sub = Z_flat[idx], Y_flat[idx]
    else:
        Z_sub, Y_sub = Z_flat, Y_flat

    lo, hi = 1e-8, 10.0
    best_beta = None
    for _ in range(30):
        alpha = (lo + hi) / 2
        lasso = Lasso(alpha=alpha, fit_intercept=False, max_iter=3000, warm_start=True)
        lasso.fit(Z_sub, Y_sub)
        nz = np.sum(np.abs(lasso.coef_) > 1e-8)
        if nz == num_keep:
            best_beta = lasso.coef_; break
        elif nz > num_keep:
            lo = alpha
        else:
            hi = alpha
        best_beta = lasso.coef_

    beta = best_beta
    kept = sorted(np.argsort(-np.abs(beta))[:num_keep].tolist())
    beta_t = torch.tensor(beta, dtype=weight.dtype)

    parts = []
    for i in kept:
        Xi = X_unf[:, i*kh*kw : (i+1)*kh*kw]
        parts.append(Xi * beta_t[i])
    X_red = torch.cat(parts, dim=1)
    sol = torch.linalg.lstsq(X_red, Y).solution
    new_weight = sol.T.reshape(out_ch, num_keep, kh, kw)

    return new_weight, kept

# ─── Prune one conv's OUTPUT channels (rows) ─────────────────────────
def prune_output_channels(conv, bn, kept_indices, device=DEVICE):
    """Remove output channels not in kept_indices from conv + its BN."""
    idx = torch.tensor(kept_indices, dtype=torch.long, device=device)
    new_out = len(kept_indices)

    new_conv = nn.Conv2d(conv.in_channels, new_out,
                         kernel_size=conv.kernel_size, stride=conv.stride,
                         padding=conv.padding, bias=conv.bias is not None).to(device)
    new_conv.weight.data = conv.weight.data[idx].clone()
    if conv.bias is not None:
        new_conv.bias.data = conv.bias.data[idx].clone()

    if bn is not None:
        new_bn = nn.BatchNorm2d(new_out).to(device)
        new_bn.weight.data   = bn.weight.data[idx].clone()
        new_bn.bias.data     = bn.bias.data[idx].clone()
        new_bn.running_mean  = bn.running_mean[idx].clone()
        new_bn.running_var   = bn.running_var[idx].clone()
    else:
        new_bn = None
    return new_conv, new_bn

# ─── Prune one conv's INPUT channels (columns) ───────────────────────
def prune_input_channels(conv, kept_indices, device=DEVICE):
    idx = torch.tensor(kept_indices, dtype=torch.long, device=device)
    new_in = len(kept_indices)
    new_conv = nn.Conv2d(new_in, conv.out_channels,
                         kernel_size=conv.kernel_size, stride=conv.stride,
                         padding=conv.padding, bias=conv.bias is not None).to(device)
    new_conv.weight.data = conv.weight.data[:, idx].clone()
    if conv.bias is not None:
        new_conv.bias.data = conv.bias.data.clone()
    return new_conv

# ─── Main structured pruning ─────────────────────────────────────────
def apply_structured_pruning(model, cal_loader, device=DEVICE):
    """
    Channel-prune ResNet-18 block-by-block using He et al. 2017 method.
    For each BasicBlock we:
      1. Fix conv1 input channels to match the previous block's output
      2. Install a temporary projection shortcut so the forward pass works
      3. Collect activations at conv2's input via forward hooks
      4. Use LASSO to select which mid-channels (conv2 inputs) to keep
      5. Use least-squares to reconstruct conv2 weights
      6. Prune conv2 output channels via magnitude
      7. Install the final projection shortcut with correct dimensions
    """
    model = copy.deepcopy(model).to(device)
    model.eval()

    keep_ratio = max(0.35, 1.0 - TARGET_SPARSITY * 0.52)
    print(f"  Channel keep ratio: {keep_ratio:.2f}")

    layer_groups = [
        ("layer1", 64,  [0, 1]),
        ("layer2", 128, [0, 1]),
        ("layer3", 256, [0, 1]),
        ("layer4", 512, [0, 1]),
    ]

    prev_out_ch = 64
    prev_kept = list(range(64))

    for layer_name, base_ch, block_ids in layer_groups:
        for blk_id in block_ids:
            blk_prefix = f"{layer_name}.{blk_id}"
            conv1 = get_module(model, f"{blk_prefix}.conv1")
            bn1   = get_module(model, f"{blk_prefix}.bn1")
            conv2 = get_module(model, f"{blk_prefix}.conv2")
            bn2   = get_module(model, f"{blk_prefix}.bn2")

            cur_out = conv2.out_channels
            cur_mid = conv1.out_channels
            num_keep_mid = max(4, int(cur_mid * keep_ratio))

            # ── Step A: Prune conv1 input channels to match prev block ──
            if conv1.in_channels != len(prev_kept):
                conv1 = prune_input_channels(conv1, prev_kept, device)
                set_module(model, f"{blk_prefix}.conv1", conv1)

            # ── Step A2: Install temporary projection shortcut ──────────
            # After previous block reduced its output channels, this block's
            # identity shortcut has a dimension mismatch. We MUST fix this
            # BEFORE collect_activations (which runs model.forward end-to-end).
            ds = None
            try:
                ds = get_module(model, f"{blk_prefix}.downsample")
            except AttributeError:
                pass

            if ds is None and len(prev_kept) != cur_out:
                s = conv1.stride[0] if isinstance(conv1.stride, tuple) else conv1.stride
                tmp_proj = nn.Conv2d(len(prev_kept), cur_out,
                                     kernel_size=1, stride=s, bias=False).to(device)
                nn.init.kaiming_normal_(tmp_proj.weight)
                tmp_bn = nn.BatchNorm2d(cur_out).to(device)
                set_module(model, f"{blk_prefix}.downsample",
                           nn.Sequential(tmp_proj, tmp_bn).to(device))
            elif ds is not None and ds[0].in_channels != len(prev_kept):
                s = ds[0].stride[0] if isinstance(ds[0].stride, tuple) else ds[0].stride
                tmp_proj = nn.Conv2d(len(prev_kept), cur_out,
                                     kernel_size=1, stride=s, bias=False).to(device)
                nn.init.kaiming_normal_(tmp_proj.weight)
                tmp_bn = nn.BatchNorm2d(cur_out).to(device)
                set_module(model, f"{blk_prefix}.downsample",
                           nn.Sequential(tmp_proj, tmp_bn).to(device))

            # ── Step B: Prune conv2 input channels using LASSO + lstsq ──
            try:
                X2, _ = collect_activations(model, f"{blk_prefix}.conv2",
                                            cal_loader, device)
                new_w2, kept_mid = channel_prune_layer(
                    conv2.weight.data.cpu(), X2, num_keep_mid,
                    conv2.padding[0], conv2.stride[0]
                )
                new_conv2 = nn.Conv2d(
                    num_keep_mid, cur_out,
                    kernel_size=conv2.kernel_size, stride=conv2.stride,
                    padding=conv2.padding, bias=conv2.bias is not None
                ).to(device)
                new_conv2.weight.data = new_w2.to(device)
                set_module(model, f"{blk_prefix}.conv2", new_conv2)
                conv2 = new_conv2

                conv1_new, bn1_new = prune_output_channels(
                    get_module(model, f"{blk_prefix}.conv1"),
                    get_module(model, f"{blk_prefix}.bn1"),
                    kept_mid, device)
                set_module(model, f"{blk_prefix}.conv1", conv1_new)
                set_module(model, f"{blk_prefix}.bn1", bn1_new)

                print(f"  {blk_prefix}: conv2 in {cur_mid}->{num_keep_mid} "
                      f"(LASSO + lstsq reconstructed)")
            except Exception as e:
                print(f"  Warning: LASSO failed for {blk_prefix}: {e}")
                print(f"  Falling back to magnitude-based channel selection.")
                conv1 = get_module(model, f"{blk_prefix}.conv1")
                bn1 = get_module(model, f"{blk_prefix}.bn1")
                importance = conv1.weight.data.abs().sum(dim=[1, 2, 3])
                _, topk_idx = importance.topk(num_keep_mid)
                kept_mid = sorted(topk_idx.cpu().tolist())

                conv1_new, bn1_new = prune_output_channels(conv1, bn1, kept_mid, device)
                set_module(model, f"{blk_prefix}.conv1", conv1_new)
                set_module(model, f"{blk_prefix}.bn1", bn1_new)

                conv2 = prune_input_channels(
                    get_module(model, f"{blk_prefix}.conv2"), kept_mid, device)
                set_module(model, f"{blk_prefix}.conv2", conv2)
                print(f"  {blk_prefix}: conv2 in {cur_mid}->{num_keep_mid} (magnitude)")

            # ── Step C: Prune conv2 output channels (magnitude) ──
            num_keep_out = max(4, int(cur_out * keep_ratio))
            conv2 = get_module(model, f"{blk_prefix}.conv2")
            bn2 = get_module(model, f"{blk_prefix}.bn2")
            importance_out = conv2.weight.data.abs().sum(dim=[1, 2, 3])
            _, topk_out = importance_out.topk(num_keep_out)
            kept_out = sorted(topk_out.cpu().tolist())

            conv2_new, bn2_new = prune_output_channels(conv2, bn2, kept_out, device)
            set_module(model, f"{blk_prefix}.conv2", conv2_new)
            set_module(model, f"{blk_prefix}.bn2", bn2_new)
            print(f"  {blk_prefix}: conv2 out {cur_out}->{num_keep_out}")

            # ── Step D: Final shortcut with correct dimensions ──
            ds = None
            try:
                ds = get_module(model, f"{blk_prefix}.downsample")
            except AttributeError:
                pass

            need_proj = (len(prev_kept) != num_keep_out)
            conv1_cur = get_module(model, f"{blk_prefix}.conv1")
            s = conv1_cur.stride[0] if isinstance(conv1_cur.stride, tuple) else conv1_cur.stride

            if need_proj:
                new_ds_conv = nn.Conv2d(len(prev_kept), num_keep_out,
                                        kernel_size=1, stride=s, bias=False).to(device)
                if ds is not None:
                    old_ds_conv = ds[0]
                    old_ds_bn = ds[1]
                    oi, oo = old_ds_conv.in_channels, old_ds_conv.out_channels
                    kept_out_t = torch.tensor(kept_out, device=device)
                    prev_kept_t = torch.tensor(prev_kept, device=device)
                    can_slice = (max(kept_out) < oo and max(prev_kept) < oi)
                    if can_slice:
                        new_ds_conv.weight.data = old_ds_conv.weight.data[kept_out_t][:, prev_kept_t].clone()
                    else:
                        nn.init.kaiming_normal_(new_ds_conv.weight)
                    new_ds_bn = nn.BatchNorm2d(num_keep_out).to(device)
                    if max(kept_out) < oo:
                        new_ds_bn.weight.data = old_ds_bn.weight.data[kept_out_t].clone()
                        new_ds_bn.bias.data = old_ds_bn.bias.data[kept_out_t].clone()
                        new_ds_bn.running_mean = old_ds_bn.running_mean[kept_out_t].clone()
                        new_ds_bn.running_var = old_ds_bn.running_var[kept_out_t].clone()
                else:
                    nn.init.kaiming_normal_(new_ds_conv.weight)
                    new_ds_bn = nn.BatchNorm2d(num_keep_out).to(device)

                set_module(model, f"{blk_prefix}.downsample",
                           nn.Sequential(new_ds_conv, new_ds_bn).to(device))
            elif ds is not None and not need_proj:
                set_module(model, f"{blk_prefix}.downsample", None)

            prev_kept = list(range(num_keep_out))
            prev_out_ch = num_keep_out

    # ── Update the FC layer ──
    fc = get_module(model, "fc")
    if fc.in_features != prev_out_ch:
        new_fc = nn.Linear(prev_out_ch, 10).to(device)
        if prev_out_ch <= fc.in_features:
            new_fc.weight.data = fc.weight.data[:, :prev_out_ch].clone()
            new_fc.bias.data = fc.bias.data.clone()
        else:
            nn.init.kaiming_normal_(new_fc.weight)
        set_module(model, "fc", new_fc)

    return model

# ─── Fine-tuning ──────────────────────────────────────────────────────
def finetune_structured(model, train_loader, test_loader, epochs=20,
                        lr=0.01, device=DEVICE):
    optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    criterion = nn.CrossEntropyLoss()
    history = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}

    for epoch in range(epochs):
        train_loss, train_acc = train_one_epoch(model, train_loader, optimizer, criterion, device)
        scheduler.step()
        model.eval()
        val_loss, val_correct, val_total = 0.0, 0, 0
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                val_loss += loss.item() * labels.size(0)
                _, pred = outputs.max(1)
                val_correct += pred.eq(labels).sum().item()
                val_total += labels.size(0)
        val_loss /= val_total
        val_acc = 100.0 * val_correct / val_total
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["train_acc"].append(train_acc)
        history["val_acc"].append(val_acc)
        print(f"  [Structured FT] Epoch {epoch+1}/{epochs}: "
              f"Train Acc={train_acc:.2f}%, Val Acc={val_acc:.2f}%")
    return history


def plot_structured_curves(history, save_path=None):
    """Plot Task 3 fine-tuning loss and accuracy curves."""
    if save_path is None:
        save_path = os.path.join(ASSETS, "task3_training_curves.png")
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    epochs = range(1, len(history["train_loss"]) + 1)
    axes[0].plot(epochs, history["train_loss"], label="Train")
    axes[0].plot(epochs, history["val_loss"], label="Val")
    axes[0].set(xlabel="Epoch", ylabel="Loss", title="Task 3: Fine-tuning Loss")
    axes[0].legend(); axes[0].grid(alpha=0.3)
    axes[1].plot(epochs, history["train_acc"], label="Train")
    axes[1].plot(epochs, history["val_acc"], label="Val")
    axes[1].set(xlabel="Epoch", ylabel="Top-1 (%)", title="Task 3: Fine-tuning Accuracy")
    axes[1].legend(); axes[1].grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Task 3 curves saved to {save_path}")


# ─── Main ─────────────────────────────────────────────────────────────
def run_task3(data_dir="./data", run_training=False):
    print("\n" + "=" * 60)
    print("  TASK 3: Structured (Channel) Pruning")
    print("=" * 60)
    print(f"  Target sparsity: {TARGET_SPARSITY*100:.0f}%")
    print(f"  Using PRETRAINED checkpoint")

    loaders = get_dataloaders(data_dir)
    train_loader = loaders["train"]
    test_loader = loaders["test"]
    train_eval_loader = loaders["train_eval"]

    print("\n[Step 3.1] Loading pretrained model and calibration data...")
    model = load_pretrained_resnet18(DEVICE)

    from torch.utils.data import Subset, DataLoader
    cal_indices = torch.randperm(len(train_loader.dataset))[:512].tolist()
    cal_dataset = Subset(train_loader.dataset, cal_indices)
    cal_loader = DataLoader(cal_dataset, batch_size=64, shuffle=False, num_workers=2)

    pre_metrics = evaluate(model, test_loader, DEVICE)
    print(f"  Pre-pruning: Top-1={pre_metrics['top1']:.2f}%")

    print("\n[Steps 3.2-3.4] Applying structured channel pruning...")
    pruned_model = apply_structured_pruning(model, cal_loader, DEVICE)

    post_metrics = evaluate(pruned_model, test_loader, DEVICE)
    print(f"\n  Post-pruning (before FT): Top-1={post_metrics['top1']:.2f}%")

    pruned_total, _ = count_parameters(pruned_model)
    orig_total, _ = count_parameters(model)
    actual_sparsity = 1.0 - pruned_total / orig_total
    print(f"  Parameters: {orig_total:,} -> {pruned_total:,} (reduction={actual_sparsity*100:.1f}%)")

    torch.save({
        'model_state_dict': pruned_model.state_dict(),
        'pre_ft_metrics': post_metrics,
        'actual_sparsity': actual_sparsity,
    }, os.path.join(ASSETS, "task3_pruned_pre_ft.pt"))

    if not run_training:
        print("\n  Pruning applied. Run with run_training=True to fine-tune.")
        return {"pre_ft_metrics": post_metrics, "actual_sparsity": actual_sparsity}

    print(f"\n[Step 3.6] Fine-tuning ({20} epochs)...")
    history = finetune_structured(pruned_model, train_loader, test_loader,
                                  epochs=20, lr=0.01, device=DEVICE)
    plot_structured_curves(history)

    print("\n[Step 3.7] Profiling...")
    final_train = evaluate(pruned_model, train_eval_loader, DEVICE)
    final_test = evaluate(pruned_model, test_loader, DEVICE)
    final_profile = profile_model(pruned_model, test_loader, DEVICE,
                                   label="Structured Pruned (Fine-tuned)")

    torch.save({'model_state_dict': pruned_model.state_dict(), 'history': history},
               os.path.join(ASSETS, "task3_finetuned.pt"))

    results = {
        "pre_ft_metrics": post_metrics,
        "actual_sparsity": actual_sparsity,
        **{f"train_{k}": v for k, v in final_train.items()},
        **{f"test_{k}": v for k, v in final_test.items()},
        **final_profile,
        "history": history,
    }
    save_results(results, os.path.join(ASSETS, "task3_results.json"))
    print("\n  All Task 3 results saved.")
    return results

if __name__ == "__main__":
    run_task3(run_training=False)
