"""
Task 0: Load and Profile the Base Model (dense FP32 baseline).
"""
import os
import sys
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import (DEVICE, BATCH_SIZE, CIFAR10_MEAN, CIFAR10_STD, ASSETS,
                   load_pretrained_resnet18, get_dataloaders, full_eval,
                   profile_model, save_results)


def verify_checkpoint(model):
    """Strict-load check: every key/shape of resnet18.pt matches the architecture."""
    from utils import REPO_DIR
    path = os.path.join(REPO_DIR, "cifar10_models", "state_dicts", "resnet18.pt")
    sd = torch.load(path, map_location="cpu")
    ref = model.state_dict()
    missing = [k for k in ref if k not in sd]
    unexpected = [k for k in sd if k not in ref]
    shape_err = [k for k in ref if k in sd and tuple(sd[k].shape) != tuple(ref[k].shape)]
    same = all(torch.equal(sd[k].cpu(), ref[k].cpu()) for k in ref if k in sd)
    print(f"  Checkpoint: {path}")
    print(f"  Tensors: {len(sd)} | missing: {len(missing)} | unexpected: {len(unexpected)} "
          f"| shape mismatches: {len(shape_err)} | weights identical to file: {same}")
    assert not (missing or unexpected or shape_err) and same
    with torch.no_grad():
        assert model(torch.zeros(2, 3, 32, 32, device=DEVICE)).shape == (2, 10)
    print("  Output shape check (2, 10): OK")


def run_task0(data_dir="./data"):
    print("=" * 60 + "\n  TASK 0: Load and Profile the Base Model\n" + "=" * 60)
    print("\n[0.1] Loading pretrained ResNet-18 (huyvnphan/PyTorch_CIFAR10, resnet18.pt)")
    model = load_pretrained_resnet18(DEVICE)
    verify_checkpoint(model)

    print("\n[0.2-0.5] CIFAR-10 data and preprocessing")
    loaders = get_dataloaders(data_dir)
    setup = {
        "batch_size": BATCH_SIZE, "input_resolution": "3x32x32",
        "normalization_mean": CIFAR10_MEAN, "normalization_std": CIFAR10_STD,
        "train_augmentation": "RandomCrop(32, padding=4) + RandomHorizontalFlip",
        "test_preprocessing": "ToTensor + Normalize (no augmentation)",
        "train_split": len(loaders["train"].dataset), "val_split": len(loaders["val"].dataset),
        "test_split": len(loaders["test"].dataset),
    }
    for k, v in setup.items():
        print(f"  {k:<22s}: {v}")

    print("\n[0.6] Evaluating full-precision model")
    metrics = full_eval(model, loaders)
    for k in ["train_top1", "train_top5", "train_macro_f1", "test_top1", "test_top5", "test_macro_f1"]:
        print(f"  {k:<16s}: {metrics[k]:.2f}%")

    print("\n[0.7] Profiling (same batch size / GPU / procedure used for every later model)")
    prof = profile_model(model, loaders["test"], DEVICE, label="Dense FP32 ResNet-18")
    results = {**setup, **metrics, **prof, "gpu": torch.cuda.get_device_name(0)}
    save_results(results, os.path.join(ASSETS, "task0_results.json"))
    print("\n  Saved report_assets/task0_results.json")
    return model, results


if __name__ == "__main__":
    run_task0()
