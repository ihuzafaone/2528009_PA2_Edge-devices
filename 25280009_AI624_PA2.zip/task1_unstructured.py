"""
Task 1: Unstructured Post-Training (magnitude) Pruning of the pretrained ResNet-18.
"""
import os
import sys
import json
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import (DEVICE, TARGET_SPARSITY, ASSETS, QUICK, load_pretrained_resnet18,
                   get_dataloaders, get_eligible_layers, get_module, evaluate, full_eval,
                   profile_model, compute_sparsity, mask_sparsity, apply_masks,
                   verify_masks, save_coo, load_coo_state, to_coo_inference_model,
                   finetune, save_results, load_results)

SENS_LEVELS = [0, 10, 20, 50, 70, 80, 90]
MAX_LAYER_SPARSITY = 0.90      # highest level measured in the sensitivity sweep
FT_EPOCHS = 20 if not QUICK else 1
FT_LR = 1e-3


def magnitude_mask(weight, sparsity):
    """Binary mask pruning exactly round(sparsity*N) smallest-|w| weights (I_i = |W_i|)."""
    k = int(round(sparsity * weight.numel()))
    mask = torch.ones_like(weight)
    if k > 0:
        idx = weight.detach().abs().flatten().topk(k, largest=False).indices
        mask.view(-1)[idx] = 0
    return mask


# ─── 1. Layer-wise sensitivity ────────────────────────────────────────
def sensitivity_analysis(loaders):
    """Prune ONE layer at a time from the dense checkpoint, evaluate w/o fine-tuning, restore."""
    model = load_pretrained_resnet18(DEVICE)
    dense = {k: v.clone() for k, v in model.state_dict().items()}
    results = {}
    for name, mod in get_eligible_layers(model):
        results[name] = {}
        for s in SENS_LEVELS:
            model.load_state_dict(dense)                       # restore original dense model
            with torch.no_grad():
                mod.weight.mul_(magnitude_mask(mod.weight, s / 100))
            results[name][s] = evaluate(model, loaders["test"])["top1"]
        print(f"  {name:<24s} " + " ".join(f"{results[name][s]:6.2f}" for s in SENS_LEVELS))
    model.load_state_dict(dense)
    return results


def plot_sensitivity(sens):
    plt.figure(figsize=(13, 7))
    for name, accs in sens.items():
        plt.plot(SENS_LEVELS, [accs[s] for s in SENS_LEVELS], marker="o", lw=1.4, label=name)
    plt.xlabel("Sparsity of the single pruned layer (%)")
    plt.ylabel("Test Top-1 (%) — no fine-tuning")
    plt.title("Layer-wise pruning sensitivity (ResNet-18, CIFAR-10)")
    plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=7)
    plt.grid(alpha=.3)
    plt.tight_layout()
    plt.savefig(os.path.join(ASSETS, "sensitivity_analysis.png"), dpi=150)
    plt.close()


# ─── 2. Local magnitude pruning (sensitivity-driven allocation) ────────
def assign_local_sparsities(sens, sizes, target=TARGET_SPARSITY, step=0.01):
    """
    Greedy allocation on the measured sensitivity curves.
    drop_l(s) = acc_dense - acc_l(s), linearly interpolated and made monotone.
    Repeatedly raise the sparsity (by 1%) of the layer whose marginal accuracy drop
    PER PRUNED WEIGHT is smallest, until the overall sparsity equals the target.
    => sensitive layers (steep curves) keep low sparsity, robust layers get high sparsity.
    Layers are capped at 90% (largest measured level).
    """
    grid = np.round(np.arange(0, MAX_LAYER_SPARSITY + 1e-9, step), 4)
    curves = {}
    for n, accs in sens.items():
        xs = np.array(SENS_LEVELS) / 100
        drop = np.maximum(0, accs[0] - np.array([accs[s] for s in SENS_LEVELS]))
        curves[n] = np.maximum.accumulate(np.interp(grid, xs, drop))
    pos = {n: 0 for n in sens}
    total = sum(sizes.values())
    target_zeros = target * total
    zeros = 0.0
    while zeros < target_zeros - 0.5:
        best = None
        for n in sens:
            i = pos[n]
            if i + 1 >= len(grid):
                continue
            cost = (curves[n][i + 1] - curves[n][i]) / (step * sizes[n])
            key = (cost, -sizes[n])
            if best is None or key < best[0]:
                best = (key, n)
        n = best[1]
        pos[n] += 1
        zeros += step * sizes[n]
    alloc = {n: grid[pos[n]] for n in sens}
    # exact fix-up: remove the overshoot from the last-chosen (largest, most robust) layer
    over = zeros - target_zeros
    alloc[n] = alloc[n] - over / sizes[n]
    return alloc


def apply_local_pruning(model, alloc):
    masks = {}
    for name, mod in get_eligible_layers(model):
        masks[name] = magnitude_mask(mod.weight, alloc[name])
    apply_masks(model, masks)
    return masks


# ─── 3. Global magnitude pruning ──────────────────────────────────────
def apply_global_pruning(model, target=TARGET_SPARSITY):
    """One global |w| threshold over all eligible weights (exactly target*N pruned)."""
    layers = get_eligible_layers(model)
    flat = torch.cat([m.weight.detach().abs().flatten() for _, m in layers])
    k = int(round(target * flat.numel()))
    prune_idx = flat.topk(k, largest=False).indices
    joint = torch.ones_like(flat)
    joint[prune_idx] = 0
    threshold = flat[prune_idx].max().item()
    masks, off = {}, 0
    for name, m in layers:
        n = m.weight.numel()
        masks[name] = joint[off:off + n].view_as(m.weight).clone()
        off += n
    apply_masks(model, masks)
    return masks, threshold


def plot_layer_sparsity(local, glob):
    names = list(local)
    x = np.arange(len(names))
    plt.figure(figsize=(14, 5.5))
    plt.bar(x - .2, [100 * local[n] for n in names], .4, label="Local (sensitivity-based)")
    plt.bar(x + .2, [100 * glob[n] for n in names], .4, label="Global (single threshold)")
    plt.xticks(x, names, rotation=60, ha="right", fontsize=7)
    plt.ylabel("Layer sparsity (%)")
    plt.title(f"Per-layer sparsity at {TARGET_SPARSITY:.0%} overall sparsity")
    plt.legend()
    plt.grid(alpha=.3, axis="y")
    plt.tight_layout()
    plt.savefig(os.path.join(ASSETS, "local_vs_global_sparsity.png"), dpi=150)
    plt.close()


def plot_curves(hl, hg):
    fig, ax = plt.subplots(1, 2, figsize=(14, 5))
    for h, lab in [(hl, "Local"), (hg, "Global")]:
        ep = range(1, len(h["train_loss"]) + 1)
        ax[0].plot(ep, h["train_loss"], label=f"{lab} train")
        ax[0].plot(ep, h["val_loss"], "--", label=f"{lab} val")
        ax[1].plot(ep, h["train_acc"], label=f"{lab} train")
        ax[1].plot(ep, h["val_acc"], "--", label=f"{lab} val")
    ax[0].set(title="Fine-tuning loss", xlabel="Epoch", ylabel="Cross-entropy")
    ax[1].set(title="Fine-tuning accuracy", xlabel="Epoch", ylabel="Top-1 (%)")
    for a in ax:
        a.grid(alpha=.3)
        a.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(ASSETS, "task1_training_curves.png"), dpi=150)
    plt.close()


# ─── Orchestration ────────────────────────────────────────────────────
def run_task1(data_dir="./data", run_training=True):
    print("=" * 60 + "\n  TASK 1: Unstructured Post-Training Pruning\n" + "=" * 60)
    loaders = get_dataloaders(data_dir)

    # ── 1.1 Sensitivity analysis (cached if available) ──
    sens_path = os.path.join(ASSETS, "sensitivity_results.json")
    if os.path.exists(sens_path):
        print("\n[1.1] Loading cached sensitivity results...")
        sens_raw = load_results(sens_path)
        # JSON converts int keys to strings; restore them
        sens = {layer: {int(k): v for k, v in accs.items()} for layer, accs in sens_raw.items()}
    else:
        print("\n[1.1] Layer-wise sensitivity (one layer pruned, others dense, no fine-tuning)")
        print(f"  {'layer':<24s} " + " ".join(f"{s:>5d}%" for s in SENS_LEVELS))
        sens = sensitivity_analysis(loaders)
        save_results(sens, sens_path)
    plot_sensitivity(sens)
    print(f"  Sensitivity plot saved to {os.path.join(ASSETS, 'sensitivity_analysis.png')}")

    print(f"\n[1.2] Local magnitude pruning (target overall sparsity {TARGET_SPARSITY:.0%})")
    local = load_pretrained_resnet18(DEVICE)
    sizes = {n: m.weight.numel() for n, m in get_eligible_layers(local)}
    alloc = assign_local_sparsities(sens, sizes)
    local_masks = apply_local_pruning(local, alloc)
    s_local, local_layer = compute_sparsity(local)
    for n in alloc:
        print(f"  {n:<24s} assigned {100 * alloc[n]:6.2f}%   measured {100 * local_layer[n]:6.2f}%"
              f"   (N={sizes[n]:,})")
    print(f"  Overall sparsity  s = 1 - sum||M||_0 / sum N  = {100 * mask_sparsity(local_masks):.4f}%")

    print(f"\n[1.3] Global magnitude pruning at the SAME overall sparsity")
    glob = load_pretrained_resnet18(DEVICE)
    global_masks, thr = apply_global_pruning(glob, mask_sparsity(local_masks))
    s_glob, glob_layer = compute_sparsity(glob)
    print(f"  Global |w| threshold = {thr:.6f}")
    for n in glob_layer:
        print(f"  {n:<24s} automatically assigned sparsity {100 * glob_layer[n]:6.2f}%")
    fully = [n for n, m in global_masks.items() if m.sum() == 0]
    print(f"  Overall sparsity: {100 * mask_sparsity(global_masks):.4f}% | "
          f"completely-pruned layers: {fully if fully else 'NONE'}")
    plot_layer_sparsity(local_layer, glob_layer)

    pre_local, pre_glob = full_eval(local, loaders), full_eval(glob, loaders)
    print(f"\n  Before fine-tuning: local test Top-1 {pre_local['test_top1']:.2f}% | "
          f"global test Top-1 {pre_glob['test_top1']:.2f}%")
    verify_masks(local, local_masks, "(local, before FT)")
    verify_masks(glob, global_masks, "(global, before FT)")

    # Save pre-FT checkpoints
    torch.save({"model_state_dict": local.state_dict(), "masks": local_masks},
               os.path.join(ASSETS, "task1_local_pre_ft.pt"))
    torch.save({"model_state_dict": glob.state_dict(), "masks": global_masks},
               os.path.join(ASSETS, "task1_global_pre_ft.pt"))

    if not run_training:
        print("\n  Sensitivity + pruning analysis complete. Run with run_training=True to fine-tune.")
        return {"sensitivity": sens, "local_allocation": alloc, "target_sparsity": TARGET_SPARSITY,
                "pre_local": pre_local, "pre_glob": pre_glob}

    print(f"\n[1.4] Fine-tuning both models: SGD(momentum .9, wd 5e-4), lr {FT_LR}, cosine, "
          f"{FT_EPOCHS} epochs, batch 128, seed 42; masks re-applied after every step")
    h_local = finetune(local, loaders, FT_EPOCHS, FT_LR, masks=local_masks, label="Local")
    h_glob = finetune(glob, loaders, FT_EPOCHS, FT_LR, masks=global_masks, label="Global")
    plot_curves(h_local, h_glob)

    print("\n[1.5] Mask verification after fine-tuning")
    v_local, ok_l = verify_masks(local, local_masks, "(local, after FT)")
    v_glob, ok_g = verify_masks(glob, global_masks, "(global, after FT)")

    print("\n[1.6] Sparse COO storage (values, indices, shapes, masks)")
    coo = {}
    for tag, m, masks in [("local", local, local_masks), ("global", glob, global_masks)]:
        path = os.path.join(ASSETS, f"task1_{tag}_coo")
        coo[tag] = save_coo(m, masks, path)
        rt = load_coo_state(path + "_compact.pt")
        same = all(torch.equal(rt[k].cpu(), v.cpu()) for k, v in m.state_dict().items())
        coo[tag]["roundtrip_exact"] = same
        c = coo[tag]
        print(f"  {tag:<6s} dense {c['dense_file_mb']:.2f} MB | COO(int64 idx + bool masks) "
              f"{c['coo_int64_file_mb']:.2f} MB | COO(int16 idx + packed masks) "
              f"{c['coo_compact_file_mb']:.2f} MB | round-trip exact: {same}")
        torch.save({"model_state_dict": m.state_dict(), "masks": masks},
                   os.path.join(ASSETS, f"task1_{tag}_finetuned.pt"))

    print("\n[1.7] Profiling: dense-masked inference and COO inference")
    print("  NOTE: PyTorch has no sparse Conv2d kernel -> in the COO model every conv weight is")
    print("  converted from COO back to dense before F.conv2d; the linear layer uses torch.sparse.mm.")
    results = {"target_sparsity": TARGET_SPARSITY, "local_allocation": alloc, "sensitivity": sens,
               "global_threshold": thr, "fully_pruned_layers": fully}
    for tag, m, pre, hist, ver, ok in [("local", local, pre_local, h_local, v_local, ok_l),
                                       ("global", glob, pre_glob, h_glob, v_glob, ok_g)]:
        post = full_eval(m, loaders)
        dense_prof = profile_model(m, loaders["test"], label=f"{tag} magnitude — dense-masked")
        coo_prof = profile_model(to_coo_inference_model(m), loaders["test"],
                                 label=f"{tag} magnitude — COO inference", stats_model=m)
        _, layer_sp = compute_sparsity(m)
        results[tag] = {"overall_sparsity": compute_sparsity(m)[0], "layer_sparsity": layer_sp,
                        "pre_ft": pre, **post, "recovered_pp": post["test_top1"] - pre["test_top1"],
                        "dense_masked_profile": dense_prof, "coo_profile": coo_prof,
                        "coo_storage": coo[tag], "history": hist,
                        "mask_verification": ver, "masks_ok": ok}
        print(f"  {tag}: train Top-1 {post['train_top1']:.2f} Top-5 {post['train_top5']:.2f} | "
              f"test Top-1 {post['test_top1']:.2f} Top-5 {post['test_top5']:.2f} "
              f"F1 {post['test_macro_f1']:.2f} | recovered {results[tag]['recovered_pp']:+.2f} pp")
    save_results(results, os.path.join(ASSETS, "task1_results.json"))
    print("\n  Saved report_assets/task1_results.json")
    return results


if __name__ == "__main__":
    run_task1()
