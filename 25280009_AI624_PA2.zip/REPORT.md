# AI624 PA2: Neural Network Pruning — Report

## Overview

This report presents results from pruning a ResNet-18 model trained on CIFAR-10 using three different approaches:
1. **Unstructured post-training pruning** (magnitude-based, local and global)
2. **Saliency-based iterative pruning** (magnitude and GraSP)
3. **Structured channel pruning** (regression-based, He et al., 2017)

**Target sparsity:** 80% for unstructured methods (Tasks 1 & 2). We chose 80% because it is aggressive enough to reveal meaningful accuracy–efficiency tradeoffs while remaining recoverable through fine-tuning, and lies in the commonly reported 70–90% range for ResNet-18 on CIFAR-10 in the pruning literature. For structured pruning (Task 3), the effective parameter reduction is 65.9% due to the coarser granularity of channel-level pruning (see discussion in Task 3).

**Architecture:** ResNet-18 from [PyTorch_CIFAR10](https://github.com/huyvnphan/PyTorch_CIFAR10) with the CIFAR-10 adaptation (3×3 initial conv instead of 7×7, no stride-2 in stem).

---

## Task 0: Load and Profile the Base Model

### Configuration

| Parameter | Value |
|-----------|-------|
| Batch Size | 128 |
| Input Resolution | 32 × 32 × 3 |
| Normalization Mean | (0.4914, 0.4822, 0.4465) |
| Normalization Std | (0.2471, 0.2435, 0.2616) |
| Train Augmentation | RandomCrop(32, padding=4), RandomHorizontalFlip |
| Test Preprocessing | Normalize only |

### Baseline Results

| Metric | Value |
|--------|-------|
| Total Parameters | 11,173,962 |
| Trainable Parameters | 11,173,962 |
| Serialized Model Size | 42.70 MB |
| MACs | 141,000,192 |
| FLOPs | 282,000,384 |
| Train Top-1 Accuracy | 99.87% |
| Train Top-5 Accuracy | 100.00% |
| Test Top-1 Accuracy | 93.07% |
| Test Top-5 Accuracy | 99.74% |
| Macro-F1 Score | 93.07% |
| Avg Inference Latency | 13.90 ms |
| Peak GPU Memory | 106.93 MB |
| Avg GPU Memory | 42.93 MB |
| CPU Energy (J) | 6.28 |
| GPU Energy (J) | 85.20 |

---

## Task 1: Unstructured Post-Training Pruning

### Step 1.1: Layer-wise Sensitivity Analysis

For each convolutional and linear layer, we independently pruned at sparsity levels $\{0, 10, 20, 50, 70, 80, 90\}\%$ and measured test accuracy without fine-tuning.

![Sensitivity Analysis](report_assets/sensitivity_analysis.png)

**Key observations:**
- **`conv1`** is extremely sensitive: accuracy drops from 93.07% to **42.32%** at 80% sparsity, and to 21.42% at 90%.
- **`layer4` layers** are almost completely insensitive: `layer4.1.conv2` maintains 93.07–93.09% across *all* sparsity levels.
- **`layer2.0.conv1`** shows moderate sensitivity (88.47% at 80%), being a stride-2 transition layer.
- The **FC layer** is surprisingly robust (93.08% at 80% sparsity) due to its small size (5,120 weights).

### Step 1.2: Local Magnitude Pruning

Per-layer sparsities assigned based on sensitivity analysis (selected examples):

| Layer | Sensitivity (acc drop at 80%) | Assigned Sparsity |
|-------|-------------------------------|-------------------|
| conv1 | 50.75 pp | 42.2% |
| layer2.0.conv1 | 4.60 pp | 76.7% |
| layer3.1.conv1 | 0.14 pp | 80.0% |
| layer4.1.conv2 | 0.00 pp | 80.1% |

Overall sparsity achieved: **80.00%**. Pre-fine-tune accuracy: **44.48%**.

### Step 1.3: Global Magnitude Pruning

A single magnitude threshold was applied across all eligible weights to achieve 80% overall sparsity. The resulting per-layer sparsity distribution:

| Layer | Global Sparsity |
|-------|----------------|
| conv1 | 17.0% |
| layer1.0.conv1 | 26.9% |
| layer3.1.conv2 | 66.7% |
| layer4.0.conv1 | 90.3% |
| layer4.1.conv1 | **99.4%** |
| fc | 0.2% |

Overall sparsity: **80.00%**. Pre-fine-tune accuracy: **93.11%** (much higher than local's 44.48%).

![Local vs Global Sparsity](report_assets/local_vs_global_sparsity.png)

### Step 1.4: Fine-tuning

Both models fine-tuned for 20 epochs with SGD (lr=0.01, momentum=0.9, cosine annealing). After every optimizer step: $W^{(\ell)} \leftarrow M^{(\ell)} \odot W^{(\ell)}$.

![Training Curves](report_assets/task1_training_curves.png)

### Step 1.5: Mask Verification

All masks verified successfully for both models:
- All masked positions contain exactly zero
- Mask sparsity matches weight tensor sparsity
- Pruned weights remain zero after fine-tuning

### Step 1.6: Sparse COO Storage

| Model | Dense Size | COO Size | Reduction |
|-------|-----------|----------|-----------|
| Local Pruned | 42.70 MB | 76.66 MB | -79.5% (larger!) |
| Global Pruned | 42.70 MB | 76.59 MB | -79.4% (larger!) |

### Step 1.7: Sparse Inference

> **Important:** PyTorch does not natively support sparse convolution with COO tensors. Sparse conv tensors must be converted back to dense for `F.conv2d`. In principle, linear layers can use `torch.sparse.mm` for sparse matmul, but in our model the FC layer accounts for only 0.05% of total weights, so any benefit is negligible. Therefore, sparse COO inference provides **no measurable latency benefit** — both the dense-masked and COO-reconstructed models execute at essentially the same speed.

### Step 1.8: Comparison Table

| Configuration | Sparsity | Train Top-1 | Test Top-1 | Test Top-5 | Macro-F1 | Dense Size | COO Size | MACs | FLOPs | Latency (ms) | Peak Mem (MB) | Avg Mem (MB) | CPU E (J) | GPU E (J) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Dense Baseline | 0% | 99.87% | 93.07% | 99.74% | 93.07% | 42.70 MB | — | 141M | 282M | 13.90 | 106.93 | 42.93 | 6.28 | 85.20 |
| Local Magnitude (FT) | 80% | 99.31% | **92.55%** | 99.71% | 92.54% | 42.70 MB | 76.66 MB | 141M | 282M | 18.31 | 544.25† | 480.24† | 62.71 | 515.20 |
| Global Magnitude (FT) | 80% | 97.41% | 90.76% | 99.71% | 90.75% | 42.70 MB | 76.59 MB | 141M | 282M | 18.50 | 544.25† | 480.24† | 64.20 | 507.35 |
| Dense Masked Inference | 80% | 99.31% | 92.55% | 99.71% | 92.54% | 42.70 MB | — | 141M | 282M | 18.58 | 588.24† | 524.23† | 37.13 | 297.04 |
| Sparse COO Inference | 80% | 99.31% | 92.55% | 99.71% | 92.54% | 42.70 MB | 76.66 MB | 141M | 282M | 18.58‡ | 588.24† | 524.23† | 37.13 | 297.04 |

†Peak GPU memory is higher than baseline because profiling was performed in the same process after training; the CUDA memory allocator retains peak allocation from the training phase. This does not reflect actual inference-only memory.

‡Sparse COO inference has the same latency as dense masked inference because PyTorch does not support sparse convolution natively — COO tensors must be converted back to dense for `F.conv2d`. The COO representation only affects storage, not computation speed.

### Discussion

#### Which layers were the most sensitive to pruning?
**`conv1`** is by far the most sensitive, dropping from 93.07% to 42.32% at 80% sparsity. It has only $3 \times 64 \times 3 \times 3 = 1{,}728$ weights and captures fundamental low-level features (edges, textures) that the entire network relies on. The stride-2 transition layers (`layer2.0.conv1` at 88.47%) are moderately sensitive as they perform critical spatial downsampling while doubling channels.

#### Did global pruning produce a reasonable layer-wise sparsity distribution?
Global pruning produced a highly non-uniform distribution: it barely pruned early layers (conv1: 17%, fc: 0.2%) while aggressively pruning deep layers (layer4.1.conv1: 99.4%). This is because deeper layers with more channels tend to have smaller per-weight magnitudes due to the combination of Kaiming initialization and the width expansion. The distribution is reasonable in that it preserves the critical early features, as confirmed by the pre-fine-tune accuracy of 93.11% vs local's 44.48%.

#### How much accuracy was recovered through fine-tuning?
- **Local:** 44.48% → **92.55%** (+48.07 pp, recovering to within 0.52 pp of baseline)
- **Global:** 93.11% → **90.76%** (−2.35 pp, accuracy actually decreased slightly during fine-tuning, likely because the extremely sparse deep layers could not recover)

Local pruning benefited enormously from fine-tuning because its uniform-ish sparsity left enough capacity in each layer to re-learn. Global pruning started high but couldn't recover the nearly-dead deep layers.

#### Did COO storage reduce the actual model size?
**No.** COO format at 80% sparsity was actually ~76.6 MB, **larger** than the dense 42.7 MB. This is because COO stores coordinates (indices) for every nonzero value. For a 4D conv weight tensor, each nonzero requires 4 index values plus the value itself. At 80% sparsity (20% nonzero), the index overhead exceeds the savings. COO only becomes beneficial above ~95% sparsity for these tensor shapes.

#### Why can a model with many zero weights still have the same latency?
Dense hardware (GPUs) executes the same number of multiply-accumulate operations regardless of zero values. The computation $Y = WX$ is performed via cuBLAS/cuDNN GEMM kernels that process all elements:

$$\text{Latency} \approx \frac{\text{MACs}}{\text{Throughput}} + \text{Memory Access Time}$$

Since MACs, tensor shapes, and memory access patterns are unchanged, latency remains identical. Achieving speedup from sparsity requires either:
- **Structured sparsity** (Task 3: physically smaller tensors)
- **Sparse hardware** (NVIDIA Ampere+ structured 2:4 sparsity)
- **Sparse libraries** (cuSPARSE, but limited to specific operations)

---

## Task 2: Saliency-Based Iterative Pruning

### Setup

| Parameter | Value |
|-----------|-------|
| Initialization | Random (`pretrained=False`), seed=42 |
| Total Training Epochs | 100 |
| Optimizer | SGD (lr=0.1, momentum=0.9, weight_decay=5e-4) |
| LR Schedule | Cosine Annealing |
| Calibration Set | 256 samples, batch_size=128, 2 batches |

### Pruning Schedule and Results

| Stage | Milestone | Target Sparsity | Mag: Acc Before→After | GraSP: Acc Before→After |
|-------|-----------|-----------------|----------------------|------------------------|
| 1 | ≥20% acc | 40% | 43.98% → 44.19% | 44.36% → 10.00% |
| 2 | ≥40% acc | 60% | 54.57% → 53.33% | 41.58% → 10.00% |
| 3 | ≥60% acc | 80% | 61.51% → 60.05% | 61.68% → 10.00% |

### GraSP Score Computation

$$S_i = -\theta_i \cdot (Hg)_i$$

where $g = \nabla_\theta \mathcal{L}(\theta)$ and $Hg = \nabla_\theta(g^\top g) / 2$ is computed via a second backward pass. Weights with **lower** scores are pruned first.

**Criterion computation time:**
- Magnitude: ~0.06 s per stage (simple sorting)
- GraSP: ~6.0 s per stage (two backward passes through the network)

### Cumulative Masks

$$M^{(\ell)}_{\text{cum},k} = M^{(\ell)}_{\text{cum},k-1} \odot M^{(\ell)}_k$$

### Training Curves

![Training Curves](report_assets/task2_training_curves.png)
![Accuracy Curves](report_assets/task2_accuracy_curves.png)

### Layer-wise Remaining Weights

![Layer-wise Remaining Weights](report_assets/layer_wise_sparsity.png)

Notable difference: Iterative magnitude pruning concentrates sparsity in deep layers (layer4: ~86% sparse) while keeping early layers lighter (~35% sparse). GraSP distributes sparsity more uniformly (~80–90% across all layers), even pruning conv1 to 90.7%.

**Layer-wise remaining weight ratio (%):**

| Layer | Iter. Magnitude | Iter. GraSP |
|-------|:---------------:|:-----------:|
| conv1 | ~65% | ~9% |
| layer1.0.conv1 | ~64% | ~17% |
| layer1.0.conv2 | ~66% | ~18% |
| layer1.1.conv1 | ~63% | ~17% |
| layer1.1.conv2 | ~65% | ~18% |
| layer2.0.conv1 | ~50% | ~17% |
| layer2.0.conv2 | ~37% | ~18% |
| layer2.0.downsample.0 | ~52% | ~20% |
| layer2.1.conv1 | ~36% | ~17% |
| layer2.1.conv2 | ~30% | ~18% |
| layer3.0.conv1 | ~23% | ~18% |
| layer3.0.conv2 | ~18% | ~20% |
| layer3.0.downsample.0 | ~22% | ~20% |
| layer3.1.conv1 | ~17% | ~19% |
| layer3.1.conv2 | ~16% | ~20% |
| layer4.0.conv1 | ~14% | ~21% |
| layer4.0.conv2 | ~14% | ~22% |
| layer4.0.downsample.0 | ~14% | ~21% |
| layer4.1.conv1 | ~14% | ~22% |
| layer4.1.conv2 | ~14% | ~22% |
| fc | ~31% | ~20% |

*Values are approximate; exact values in `task2_results.json` and the bar chart above.*

### Comparison Table

**Note:** The comparison between T1 (post-training) and T2 (iterative) is not strictly apples-to-apples: T1 starts from a pretrained model and fine-tunes for 20 epochs at lr=0.01, while T2 trains from random initialization for 100 epochs at lr=0.1. The comparison highlights the tradeoff between requiring a pretrained checkpoint vs. training from scratch.

| Method | Final Train Top-1 | Final Test Top-1 | Test Top-5 | Macro-F1 | Size (MB) | COO Size (MB) | Latency (ms) | Peak Mem (MB) | Avg Mem (MB) | CPU E (J) | GPU E (J) | Criterion Time (s) |
|--------|-------------------|-----------------|------------|----------|-----------|---------------|---------------|---------------|-------------|-----------|-----------|---------------------|
| T1: Post-training Local Mag | 99.31% | **92.55%** | 99.71% | 92.54% | 42.70 | 76.66 | 18.31 | 544.25 | 480.24 | 62.71 | 515.20 | — |
| T2: Iter. Magnitude | 99.81% | 92.25% | 99.71% | 92.26% | 42.70 | 76.62 | 18.99 | 597.64 | 533.63 | 67.67 | 535.03 | 0.04 |
| T2: Iter. GraSP | 98.20% | 88.93% | 99.50% | 88.93% | 42.70 | 73.18 | 19.21 | 597.64 | 533.63 | 37.34 | 282.69 | 5.98 |

### Discussion

#### Did iterative pruning outperform post-training magnitude pruning?
**Nearly matched it.** Iterative magnitude pruning (92.25%) came within 0.30 pp of post-training local magnitude pruning (92.55%), which is remarkable considering iterative pruning started from **random weights** while post-training used a fully pretrained model. This supports the lottery ticket hypothesis: iterative pruning during training finds sparse subnetworks that train nearly as well as the dense pretrained model.

#### Did GraSP perform better than iterative magnitude pruning?
**No, GraSP performed worse** (88.93% vs 92.25%). This is likely because:
1. GraSP computes scores at a single checkpoint (~20% accuracy), where the loss landscape is poorly explored. The Hessian-gradient product at this early stage may not accurately predict long-term importance.
2. Each GraSP pruning stage caused a catastrophic accuracy drop to 10% (random chance), requiring extensive recovery training. Magnitude pruning caused much gentler drops (44→44%, 55→53%, 62→60%).
3. GraSP's uniform sparsity distribution (even 90.7% on conv1) may be suboptimal compared to magnitude's non-uniform distribution that naturally protects early layers.

#### Did any layer collapse at high sparsity?
No complete layer collapse occurred. However, GraSP pushed `conv1` to 90.7% sparsity (only ~169 weights remaining out of 1,728), which is dangerously sparse for the input layer. Despite this, training managed to recover, likely because the subsequent layers compensated.

---

## Task 3: Structured (Channel) Pruning

### Method

We implemented structured channel pruning following He et al., 2017. For each convolutional layer (starting from the second block), we:

1. **Collect input-output pairs** via forward hooks on calibration data (512 samples)
2. **Subproblem (i) — LASSO channel selection:** Using `torch.nn.functional.unfold`, extract sliding windows $X_{\text{unf}} \in \mathbb{R}^{(N \cdot L) \times (c \cdot k_h \cdot k_w)}$. For each input channel $i$, compute $Z_i = X_i W_i^\top$. Solve the LASSO:

$$\hat{\beta} = \arg\min_\beta \frac{1}{2N} \|Y - \sum_{i=1}^{c} \beta_i Z_i\|_F^2 + \lambda\|\beta\|_1$$

using `sklearn.linear_model.Lasso` with binary search on $\lambda$ until exactly $c_0$ channels remain.

3. **Subproblem (ii) — Weight reconstruction:** Construct reduced design matrix $X' = [\beta_1 X_1, \ldots, \beta_{c_0} X_{c_0}]$ and solve via `torch.linalg.lstsq`:

$$W' = \arg\min_{W'} \|Y - X' W'^\top\|_F^2$$

Reshape $W'$ back to convolutional form $(n, c_0, k_h, k_w)$.

4. **Propagation:** Output channel pruning on conv1 (to match conv2's reduced input channels), BatchNorm slicing, shortcut projection updates.

The LASSO+lstsq pipeline successfully prunes **all 8 residual blocks** (`layer1.0` through `layer4.1`). To handle the sequential dimension mismatches that arise when pruning block-by-block (each block's output channel count changes, affecting the next block's identity shortcut), we install temporary projection shortcuts before collecting activations for each block. This ensures the full model forward pass completes successfully for hook-based activation collection.

Channel keep ratio: 0.58 (58% of channels retained per layer).

### Key Implementation Details

- Pruning applied sequentially to all 8 blocks (layer1.0 through layer4.1), starting from the second convolutional block as required
- **Shortcut (downsample) handling:**
  - When pruning changes the channel count such that the residual branch and identity branch dimensions mismatch, a new 1×1 projection convolution + BatchNorm is inserted
  - Existing downsample projections are sliced to retain only the kept channel indices (both input and output dimensions)
  - Temporary projection shortcuts are installed *before* activation collection to ensure forward pass completes successfully
- **BatchNorm updates:** For every pruned conv layer, the corresponding BatchNorm's `weight`, `bias`, `running_mean`, and `running_var` are sliced to match the new channel count
- **FC layer:** Input features adjusted from 512 to the final conv output channel count; existing weights sliced accordingly
- **Channel keep ratio:** 0.58 (58% of channels retained per layer)

### Results

![Task 3 Fine-tuning Curves](report_assets/task3_training_curves.png)

| Metric | Baseline | Structured Pruned | Change |
|--------|----------|-------------------|--------|
| Parameters | 11,173,962 | 3,815,345 | **−65.9%** |
| Model Size | 42.70 MB | **14.61 MB** | **−65.8%** |
| MACs | 141M | **52M** | **−63.2%** |
| FLOPs | 282M | **104M** | **−63.1%** |
| Pre-FT Top-1 | — | 9.48% | — |
| Post-FT Top-1 | 93.07% | **86.66%** | −6.41 pp |
| Post-FT Top-5 | 99.74% | 99.47% | −0.27 pp |
| Macro-F1 | 93.07% | 86.64% | −6.43 pp |
| Latency | 13.90 ms | **11.50 ms** | **−17.3%** |
| Peak GPU Memory | 106.93 MB | 93.20 MB | −12.8% |

### Discussion

#### Did you see improvement in latency/memory while meeting accuracy constraint?
**Yes, structured pruning achieved real speedup.** Latency decreased from 13.90 ms to 11.50 ms (−17.3%), and model size dropped from 42.70 MB to 15.32 MB (−64.1%). This is the only pruning method that reduced MACs (141M → 52M, −63.2%) because entire channels are physically removed.

The accuracy drop of 6.41 pp (93.07% → 86.66%) falls within the target 5–15 pp range. The relatively low pre-fine-tune accuracy (9.48%) is because the newly added shortcut projections were randomly initialized, but fine-tuning recovered strongly to 86.66%.

Peak GPU memory also decreased (93.20 MB vs 106.93 MB baseline, −12.8%) since the pruned model has fewer channels and smaller intermediate tensors.

#### Why only 65.9% parameter reduction instead of 80%?
Channel pruning has coarser granularity than weight-level pruning: removing a fraction $f$ of channels from *both* input and output of a layer reduces parameters by roughly $1 - (1-f)^2$. With our keep ratio of 0.58, we achieve $\approx$66% parameter reduction. Pushing harder (e.g. keep_ratio=0.35) causes catastrophic accuracy collapse because entire feature maps are destroyed. This is a fundamental limitation of structured pruning — it trades pruning ratio for real hardware acceleration.

#### Structured vs. Unstructured Pruning Tradeoffs

| Aspect | Unstructured (T1/T2) | Structured (T3) |
|--------|---------------------|-----------------|
| Granularity | Individual weights | Entire channels |
| Best accuracy | **92.78%** (local mag) | 86.66% |
| Actual size reduction | None (42.70 MB) | **15.32 MB (−64.1%)** |
| Actual speedup | None (~13.9 ms) | **11.50 ms (−17.3%)** |
| MACs reduction | None (141M) | **52M (−63.2%)** |
| Hardware requirement | Sparse HW/libraries | **Standard GPU** |
| Implementation complexity | Simple | Complex (shortcuts, BN) |

---

## Grand Comparison Table

| Method | Sparsity | Test Top-1 (%) | Test Top-5 (%) | Macro-F1 (%) | Size (MB) | MACs | Latency (ms) | Peak Mem (MB) | Avg Mem (MB) | CPU Energy (J) | GPU Energy (J) |
|--------|----------|----------------|----------------|--------------|-----------|------|--------------|---------------|-------------|----------------|----------------|
| Dense Baseline | 0% | 93.07 | 99.74 | 93.07 | 42.70 | 141M | 13.90 | 106.93 | 42.93 | 6.28 | 85.20 |
| T1: Local Mag. (FT) | 80% | **92.78** | 99.62 | 92.79 | 44.77 | 141M | 14.54 | 150.27 | 86.27 | 6.16 | 87.75 |
| T1: Global Mag. (FT) | 80% | 92.90 | 99.77 | 92.89 | 44.77 | 141M | 14.20 | 150.72 | 86.72 | 5.88 | 80.55 |
| T2: Iter. Magnitude | 80% | 91.94 | 99.69 | 91.95 | 44.77 | 141M | 13.35 | 151.56 | 87.56 | 5.94 | 79.43 |
| T2: Iter. GraSP | 80% | 88.90 | 99.49 | 88.94 | 44.77 | 141M | 13.11 | 150.81 | 86.81 | 6.07 | 82.64 |
| T3: Structured | 65.9% | 86.66 | 99.47 | 86.64 | **15.32** | **52M** | **11.50** | **93.20** | 29.20 | 5.46 | 65.91 |

Peak/avg GPU memory for unstructured methods (T1/T2) is slightly higher than baseline because profiling ran in the same CUDA context after training; the allocator retains some peak allocations from optimizer buffers.

Sparse COO storage sizes: COO int64 ~91.6 MB, COO compact ~28.3 MB for T1 at 80% sparsity. COO int64 is larger than dense (44.8 MB) due to index overhead; the compact variant (int32 indices) reduces this to 28.3 MB — a 37% saving over dense. COO inference latency is identical to dense masked — PyTorch converts COO back to dense for `F.conv2d`.

---

## Energy Measurement Methodology

We use `torch.profiler` with `ProfilerActivity.CPU` and `ProfilerActivity.CUDA` to measure execution time per activity type over 50 batches. Energy is estimated as:

$$E = t_{\text{active}} \times P_{\text{TDP}}$$

where GPU TDP $\approx$ 115W (RTX 4060 Laptop) and CPU TDP $\approx$ 45W. The same methodology is used consistently across all tasks.

---

## AI Acknowledgment

I have used **Claude (Anthropic)** via Cursor IDE to assist with code scaffolding, modularization, and debugging across all four tasks (approximately 3 sessions). Specifically:
- Code structure and organization
- Implementation of profiling utilities
- Debugging tensor shape issues in structured pruning

All algorithmic understanding, analysis, and discussion are my own work.
