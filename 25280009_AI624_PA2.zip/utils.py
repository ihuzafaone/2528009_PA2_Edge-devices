"""
Shared data, evaluation, profiling, sparsity and COO helpers for AI624 PA2.
The SAME functions (and therefore the same profiling procedure) are used by
every task so that all numbers are directly comparable.
"""
import os
import sys
import io
import gc
import time
import copy
import json
import threading
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset
import torchvision
import torchvision.transforms as T
from sklearn.metrics import f1_score
from thop import profile as thop_profile
from collections import OrderedDict

# ─── Constants (identical for every task) ─────────────────────────────
CIFAR10_MEAN = (0.4914, 0.4822, 0.4465)
CIFAR10_STD = (0.2471, 0.2435, 0.2616)
BATCH_SIZE = 128
NUM_WORKERS = 4
TARGET_SPARSITY = 0.80
SEED = 42
VAL_SIZE = 5000                 # held-out validation split taken from the 50k train set
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
NUM_PROFILE_BATCHES = 100       # batches averaged for latency / memory
NUM_WARMUP_BATCHES = 10
NUM_ENERGY_BATCHES = 300        # batches used for the energy measurement
CPU_TDP_W = 55.0                # i7-14650HX base power (used only if RAPL is unavailable)
QUICK = os.environ.get("PA2_QUICK", "0") == "1"   # smoke-test mode (tiny runs)

REPO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "PyTorch_CIFAR10")
if REPO_DIR not in sys.path:
    sys.path.insert(0, REPO_DIR)
ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "report_assets")
os.makedirs(ASSETS, exist_ok=True)


def set_seed(seed=SEED):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ─── Data ─────────────────────────────────────────────────────────────
def get_train_transform():
    return T.Compose([T.RandomCrop(32, padding=4), T.RandomHorizontalFlip(),
                      T.ToTensor(), T.Normalize(CIFAR10_MEAN, CIFAR10_STD)])


def get_test_transform():
    return T.Compose([T.ToTensor(), T.Normalize(CIFAR10_MEAN, CIFAR10_STD)])


def _split_indices(n=50000, val_size=VAL_SIZE, seed=SEED):
    g = torch.Generator().manual_seed(seed)
    perm = torch.randperm(n, generator=g).tolist()
    return perm[val_size:], perm[:val_size]


def get_dataloaders(data_dir="./data", batch_size=BATCH_SIZE):
    """
    Returns a dict of loaders:
      train      : 45k images, augmented (used for all training / fine-tuning)
      val        : 5k held-out train images, no augmentation (validation curves,
                   Task 2 accuracy milestones) -> test set is never used for decisions
      test       : official 10k test set
      train_eval : full 50k train set, no augmentation (reported "Train" accuracy)
    """
    train_aug = torchvision.datasets.CIFAR10(data_dir, train=True, download=True,
                                             transform=get_train_transform())
    train_plain = torchvision.datasets.CIFAR10(data_dir, train=True, download=False,
                                               transform=get_test_transform())
    test_ds = torchvision.datasets.CIFAR10(data_dir, train=False, download=True,
                                           transform=get_test_transform())
    tr_idx, val_idx = _split_indices()
    if QUICK:
        tr_idx, val_idx = tr_idx[:2048], val_idx[:512]
        test_ds = Subset(test_ds, list(range(1024)))
        train_plain_eval = Subset(train_plain, list(range(1024)))
    else:
        train_plain_eval = train_plain
    kw = dict(num_workers=NUM_WORKERS, pin_memory=True, persistent_workers=True)
    return {
        "train": DataLoader(Subset(train_aug, tr_idx), batch_size=batch_size,
                            shuffle=True, drop_last=True, **kw),
        "val": DataLoader(Subset(train_plain, val_idx), batch_size=batch_size,
                          shuffle=False, **kw),
        "test": DataLoader(test_ds, batch_size=batch_size, shuffle=False, **kw),
        "train_eval": DataLoader(train_plain_eval, batch_size=batch_size,
                                 shuffle=False, **kw),
    }


def get_calibration_loader(data_dir="./data", per_class=100, batch_size=125, seed=SEED):
    """Class-balanced calibration subset of the TRAIN split (no augmentation)."""
    ds = torchvision.datasets.CIFAR10(data_dir, train=True, download=False,
                                      transform=get_test_transform())
    tr_idx, _ = _split_indices()
    targets = np.array(ds.targets)
    rng = np.random.RandomState(seed)
    chosen = []
    for c in range(10):
        cls = [i for i in tr_idx if targets[i] == c]
        chosen += rng.choice(cls, per_class if not QUICK else 10, replace=False).tolist()
    return DataLoader(Subset(ds, chosen), batch_size=batch_size, shuffle=False,
                      num_workers=2)


# ─── Models ───────────────────────────────────────────────────────────
def load_pretrained_resnet18(device=DEVICE):
    from cifar10_models.resnet import resnet18
    model = resnet18(pretrained=True, device="cpu")
    return model.to(device).eval()


def load_random_resnet18(device=DEVICE):
    from cifar10_models.resnet import resnet18
    return resnet18(pretrained=False).to(device)


def get_module(model, name):
    m = model
    for p in name.split('.'):
        m = getattr(m, p)
    return m


def set_module(model, name, new):
    parts = name.split('.')
    parent = get_module(model, '.'.join(parts[:-1])) if len(parts) > 1 else model
    setattr(parent, parts[-1], new)


def get_eligible_layers(model):
    """(name, module) for every Conv2d / Linear layer (the prunable weights)."""
    return [(n, m) for n, m in model.named_modules() if isinstance(m, (nn.Conv2d, nn.Linear))]


# ─── Evaluation ───────────────────────────────────────────────────────
@torch.no_grad()
def evaluate(model, loader, device=DEVICE):
    """Top-1, Top-5 (%), Macro-F1 (%) and mean cross-entropy loss."""
    model.eval()
    preds, labels_all = [], []
    c1 = c5 = n = 0
    loss_sum = 0.0
    for x, y in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        out = model(x)
        loss_sum += F.cross_entropy(out, y, reduction="sum").item()
        top5 = out.topk(5, 1).indices
        c1 += top5[:, 0].eq(y).sum().item()
        c5 += top5.eq(y[:, None]).any(1).sum().item()
        n += y.numel()
        preds.append(top5[:, 0].cpu())
        labels_all.append(y.cpu())
    p, l = torch.cat(preds).numpy(), torch.cat(labels_all).numpy()
    return {"top1": 100.0 * c1 / n, "top5": 100.0 * c5 / n,
            "macro_f1": 100.0 * f1_score(l, p, average="macro"), "loss": loss_sum / n}


def full_eval(model, loaders):
    """Train (50k, no aug) + test metrics in one dict with train_/test_ prefixes."""
    tr = evaluate(model, loaders["train_eval"])
    te = evaluate(model, loaders["test"])
    return {**{f"train_{k}": v for k, v in tr.items()}, **{f"test_{k}": v for k, v in te.items()}}


# ─── Profiling ────────────────────────────────────────────────────────
def count_parameters(model):
    return (sum(p.numel() for p in model.parameters()),
            sum(p.numel() for p in model.parameters() if p.requires_grad))


def get_model_size_mb(model):
    """Serialized size of the dense FP32 state_dict (MB = 10^6 bytes)."""
    buf = io.BytesIO()
    torch.save(model.state_dict(), buf)
    return buf.tell() / 1e6


def count_macs_flops(model, device=DEVICE):
    """Dense MACs for one 32x32 image (thop); FLOPs = 2 x MACs."""
    m = copy.deepcopy(model).to(device).eval()
    macs, _ = thop_profile(m, inputs=(torch.randn(1, 3, 32, 32, device=device),), verbose=False)
    del m
    return float(macs), 2.0 * float(macs)


def nonzero_macs(model, device=DEVICE):
    """MACs that multiply a NON-zero weight (what an ideal sparse kernel would execute)."""
    total = [0]
    hooks = []
    for _, mod in get_eligible_layers(model):
        def hook(m, inp, out):
            nnz = (m.weight != 0).sum().item()
            total[0] += nnz * (out.shape[-1] * out.shape[-2] if isinstance(m, nn.Conv2d) else 1)
        hooks.append(mod.register_forward_hook(hook))
    with torch.no_grad():
        model.eval()(torch.randn(1, 3, 32, 32, device=device))
    for h in hooks:
        h.remove()
    return float(total[0])


def _profile_batches(loader, n, device):
    """Pre-load n test batches to the GPU so data loading is excluded from timing."""
    batches, it = [], iter(loader)
    while len(batches) < n:
        try:
            x, _ = next(it)
        except StopIteration:
            it = iter(loader)
            x, _ = next(it)
        batches.append(x.to(device))
    return batches


@torch.no_grad()
def measure_latency(model, batches, device=DEVICE):
    """Mean/std latency per batch (ms) with CUDA events after NUM_WARMUP_BATCHES warm-up."""
    model.eval()
    for x in batches[:NUM_WARMUP_BATCHES]:
        model(x)
    torch.cuda.synchronize()
    lat = []
    for x in batches[:NUM_PROFILE_BATCHES]:
        s, e = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        s.record()
        model(x)
        e.record()
        torch.cuda.synchronize()
        lat.append(s.elapsed_time(e))
    return float(np.mean(lat)), float(np.std(lat))


@torch.no_grad()
def measure_gpu_memory(model, batches, device=DEVICE):
    """
    Peak / average GPU memory attributable to THIS model during inference
    (weights + activations). Memory already held by other objects in the process
    (e.g. optimizer states from earlier training) is subtracted as a baseline.
    """
    model.eval()
    model.cpu()
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.synchronize()
    base = torch.cuda.memory_allocated(device)
    model.to(device)
    torch.cuda.reset_peak_memory_stats(device)
    samples = []
    for x in batches[:NUM_PROFILE_BATCHES]:
        model(x)
        torch.cuda.synchronize()
        samples.append(torch.cuda.memory_allocated(device) - base)
    peak = torch.cuda.max_memory_allocated(device) - base
    return peak / 2**20, float(np.mean(samples)) / 2**20


def _rapl_files():
    root = "/sys/class/powercap"
    if not os.path.isdir(root):
        return []
    return [os.path.join(root, d, "energy_uj") for d in os.listdir(root)
            if d.startswith("intel-rapl:") and d.count(":") == 1
            and os.access(os.path.join(root, d, "energy_uj"), os.R_OK)]


def _read_rapl(files):
    return sum(int(open(f).read()) for f in files)


@torch.no_grad()
def measure_energy(model, batches, device=DEVICE, n_batches=NUM_ENERGY_BATCHES):
    """
    GPU energy : NVML hardware energy counter (nvmlDeviceGetTotalEnergyConsumption), in J.
    CPU energy : Intel RAPL package counter when readable. WSL2 does not expose RAPL,
                 so we fall back to  E_cpu = (process CPU-seconds / logical cores) x CPU TDP,
                 which is clearly marked as an estimate ("cpu_energy_method").
    Energy is measured over n_batches forward passes and also reported per image.
    """
    import pynvml
    model.eval()
    pynvml.nvmlInit()
    h = pynvml.nvmlDeviceGetHandleByIndex(torch.cuda.current_device())
    rapl = _rapl_files()
    for x in batches[:NUM_WARMUP_BATCHES]:
        model(x)
    torch.cuda.synchronize()
    e0 = pynvml.nvmlDeviceGetTotalEnergyConsumption(h)
    r0 = _read_rapl(rapl) if rapl else None
    c0 = time.process_time()
    t0 = time.perf_counter()
    for i in range(n_batches):
        model(batches[i % len(batches)])
    torch.cuda.synchronize()
    wall = time.perf_counter() - t0
    cpu_s = time.process_time() - c0
    gpu_j = (pynvml.nvmlDeviceGetTotalEnergyConsumption(h) - e0) / 1000.0
    if rapl:
        cpu_j, method = (_read_rapl(rapl) - r0) / 1e6, "Intel RAPL"
    else:
        cpu_j = cpu_s * CPU_TDP_W / os.cpu_count()
        method = "estimate: CPU-seconds x TDP/cores (RAPL unavailable in WSL2)"
    pynvml.nvmlShutdown()
    imgs = n_batches * batches[0].shape[0]
    return {"gpu_energy_j": gpu_j, "cpu_energy_j": cpu_j,
            "gpu_energy_mj_per_img": 1000 * gpu_j / imgs,
            "cpu_energy_mj_per_img": 1000 * cpu_j / imgs,
            "energy_wall_s": wall, "energy_images": imgs, "cpu_energy_method": method}


def profile_model(model, loader, device=DEVICE, label="Model", stats_model=None):
    """
    Common profiling procedure used for EVERY model in every task:
    params, serialized size, MACs, FLOPs, latency, peak/avg GPU memory, CPU/GPU energy.
    stats_model: model used for params/size/MACs when `model` is a wrapper (e.g. COO inference).
    """
    print(f"\n{'=' * 60}\n  Profiling: {label}\n{'=' * 60}")
    stats = stats_model if stats_model is not None else model
    model = model.to(device).eval()
    batches = _profile_batches(loader, max(NUM_PROFILE_BATCHES, NUM_WARMUP_BATCHES), device)
    total, trainable = count_parameters(stats)
    size = get_model_size_mb(stats)
    macs, flops = count_macs_flops(stats, device)
    nz_macs = nonzero_macs(stats.to(device), device)
    lat, lat_std = measure_latency(model, batches, device)
    peak, avg = measure_gpu_memory(model, batches, device)
    energy = measure_energy(model, batches, device)
    res = OrderedDict(
        total_params=total, trainable_params=trainable, nonzero_params=nonzero_param_count(stats),
        size_mb=size, macs=macs, flops=flops, nonzero_macs=nz_macs,
        avg_latency_ms=lat, std_latency_ms=lat_std,
        latency_per_img_ms=lat / batches[0].shape[0],
        peak_gpu_mem_mb=peak, avg_gpu_mem_mb=avg, **energy)
    show = [("Parameters (total / nonzero)", f"{total:,} / {res['nonzero_params']:,}"),
            ("Serialized dense size (MB)", f"{size:.2f}"),
            ("MACs (dense / nonzero)", f"{macs / 1e6:.2f}M / {nz_macs / 1e6:.2f}M"),
            ("FLOPs", f"{flops / 1e6:.2f}M"),
            (f"Latency / batch of {BATCH_SIZE} (ms)", f"{lat:.3f} ± {lat_std:.3f}"),
            ("Peak / Avg GPU memory (MB)", f"{peak:.2f} / {avg:.2f}"),
            (f"GPU energy ({energy['energy_images']} imgs, J)", f"{energy['gpu_energy_j']:.2f}"),
            ("CPU energy (J)", f"{energy['cpu_energy_j']:.2f}  [{energy['cpu_energy_method']}]")]
    for k, v in show:
        print(f"  {k:<36s} {v}")
    return dict(res)


# ─── Sparsity & masks ─────────────────────────────────────────────────
def nonzero_param_count(model):
    return int(sum((p != 0).sum().item() for p in model.parameters()))


def compute_sparsity(model):
    """Overall + per-layer sparsity over eligible (conv/linear) weights."""
    zeros = total = 0
    per = OrderedDict()
    for name, m in get_eligible_layers(model):
        z = (m.weight == 0).sum().item()
        per[name] = z / m.weight.numel()
        zeros += z
        total += m.weight.numel()
    return zeros / total, per


def mask_sparsity(masks):
    z = sum((m == 0).sum().item() for m in masks.values())
    return z / sum(m.numel() for m in masks.values())


@torch.no_grad()
def apply_masks(model, masks):
    for name, mask in masks.items():
        w = get_module(model, name).weight
        w.mul_(mask.to(w.device, w.dtype))


def verify_masks(model, masks, label="", verbose=True):
    """
    For every pruned layer: (1) masked positions are exactly zero, (2) sparsity from
    the mask equals sparsity measured on the weight tensor (weights that are
    naturally zero at kept positions are reported separately), (3) no layer collapsed.
    Returns a list of per-layer rows.
    """
    rows, ok = [], True
    for name, mask in masks.items():
        w = get_module(model, name).weight.detach()
        mask = mask.to(w.device)
        masked_nonzero = int((w[mask == 0] != 0).sum().item())
        m_sp = 1.0 - mask.float().mean().item()
        w_sp = (w == 0).float().mean().item()
        natural = int(((w == 0) & (mask != 0)).sum().item())
        match = abs((w_sp - natural / w.numel()) - m_sp) < 1e-9
        collapsed = mask.sum().item() == 0
        good = masked_nonzero == 0 and match and not collapsed
        ok &= good
        rows.append(dict(layer=name, mask_sparsity=m_sp, weight_sparsity=w_sp,
                         masked_positions_nonzero=masked_nonzero,
                         natural_zeros_at_kept=natural, match=match, collapsed=collapsed))
    if verbose:
        print(f"  Mask verification {label}: {'ALL CHECKS PASSED' if ok else 'FAILED'} "
              f"({len(rows)} layers; masked-nonzero total="
              f"{sum(r['masked_positions_nonzero'] for r in rows)}, "
              f"collapsed={[r['layer'] for r in rows if r['collapsed']]})")
    return rows, ok


# ─── COO storage & sparse inference ───────────────────────────────────
def _smallest_int(max_val):
    return torch.int16 if max_val < 2**15 else torch.int32


def save_coo(model, masks, path):
    """
    Convert every pruned weight tensor to torch.sparse COO and save
    nonzero values, indices, tensor shape and the pruning mask.
    Two files are written so the index overhead can be discussed:
      <path>_int64.pt   : torch default COO (int64 indices, bool masks)
      <path>_compact.pt : int16 indices + bit-packed masks (same information)
    Non-prunable tensors (BN, biases) are stored densely in both.
    Returns the size breakdown in MB.
    """
    dense_rest = {k: v.detach().cpu() for k, v in model.state_dict().items()
                  if not (k.endswith(".weight") and k[:-7] in masks)}
    default, compact = {"sparse": {}, "dense": dense_rest}, {"sparse": {}, "dense": dense_rest}
    vb = ib64 = ib_c = mb_bool = mb_pack = 0
    for name, mask in masks.items():
        w = get_module(model, name).weight.detach().cpu()
        coo = w.to_sparse_coo().coalesce()
        idx, val = coo.indices(), coo.values()
        idx_c = idx.to(_smallest_int(max(w.shape)))
        m_bool = mask.cpu().bool()
        m_pack = torch.from_numpy(np.packbits(m_bool.numpy().reshape(-1)))
        default["sparse"][name] = {"values": val, "indices": idx, "shape": tuple(w.shape), "mask": m_bool}
        compact["sparse"][name] = {"values": val, "indices": idx_c, "shape": tuple(w.shape), "mask_packed": m_pack}
        vb += val.numel() * 4
        ib64 += idx.numel() * 8
        ib_c += idx_c.numel() * idx_c.element_size()
        mb_bool += m_bool.numel()
        mb_pack += m_pack.numel()
    torch.save(default, path + "_int64.pt")
    torch.save(compact, path + "_compact.pt")
    rest = sum(v.numel() * v.element_size() for v in dense_rest.values())
    return {"coo_int64_file_mb": os.path.getsize(path + "_int64.pt") / 1e6,
            "coo_compact_file_mb": os.path.getsize(path + "_compact.pt") / 1e6,
            "coo_values_mb": vb / 1e6, "coo_indices_int64_mb": ib64 / 1e6,
            "coo_indices_compact_mb": ib_c / 1e6, "masks_bool_mb": mb_bool / 1e6,
            "masks_packed_mb": mb_pack / 1e6, "dense_rest_mb": rest / 1e6,
            "dense_file_mb": get_model_size_mb(model)}


def load_coo_state(path_compact):
    """Rebuild a dense state_dict from the compact COO file (round-trip check)."""
    pkg = torch.load(path_compact, map_location="cpu")
    state = dict(pkg["dense"])
    for name, item in pkg["sparse"].items():
        state[name + ".weight"] = torch.sparse_coo_tensor(
            item["indices"].long(), item["values"], item["shape"]).to_dense()
    return state


class COOConv2d(nn.Module):
    """Conv layer whose weight is STORED in COO. PyTorch has no sparse conv kernel, so the
    COO tensor is converted back to dense on every forward before F.conv2d."""
    def __init__(self, conv):
        super().__init__()
        self.register_buffer("w_coo", conv.weight.detach().to_sparse_coo().coalesce())
        self.bias = conv.bias
        self.stride, self.padding, self.dilation, self.groups = conv.stride, conv.padding, conv.dilation, conv.groups

    def forward(self, x):
        return F.conv2d(x, self.w_coo.to_dense(), self.bias, self.stride, self.padding,
                        self.dilation, self.groups)


class COOLinear(nn.Module):
    """Linear layer computed with torch.sparse.mm on the COO weight (supported natively)."""
    def __init__(self, lin):
        super().__init__()
        self.register_buffer("w_coo", lin.weight.detach().to_sparse_coo().coalesce())
        self.bias = lin.bias

    def forward(self, x):
        y = torch.sparse.mm(self.w_coo, x.t()).t()
        return y if self.bias is None else y + self.bias


def to_coo_inference_model(model):
    m = copy.deepcopy(model).eval()
    for name, mod in get_eligible_layers(m):
        set_module(m, name, COOConv2d(mod) if isinstance(mod, nn.Conv2d) else COOLinear(mod))
    return m


# ─── Training helpers ─────────────────────────────────────────────────
def train_one_epoch(model, loader, optimizer, criterion, device=DEVICE, masks=None,
                    scheduler=None, step_hook=None):
    """One epoch; masks are re-applied after EVERY optimizer step (W <- M ⊙ W)."""
    model.train()
    loss_sum = correct = total = 0
    for x, y in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        out = model(x)
        loss = criterion(out, y)
        loss.backward()
        optimizer.step()
        if masks:
            apply_masks(model, masks)
        if scheduler is not None:
            scheduler.step()
        loss_sum += loss.item() * y.size(0)
        correct += out.argmax(1).eq(y).sum().item()
        total += y.size(0)
        if step_hook is not None and step_hook():
            break
    return loss_sum / max(total, 1), 100.0 * correct / max(total, 1)


def finetune(model, loaders, epochs, lr, masks=None, label="FT", seed=SEED,
             weight_decay=5e-4, momentum=0.9):
    """SGD + cosine LR fine-tuning with fixed masks; logs train/val loss & accuracy."""
    set_seed(seed)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    crit = nn.CrossEntropyLoss()
    hist = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}
    for ep in range(epochs):
        tl, ta = train_one_epoch(model, loaders["train"], opt, crit, masks=masks)
        sched.step()
        v = evaluate(model, loaders["val"])
        for k, val in zip(hist, (tl, ta, v["loss"], v["top1"])):
            hist[k].append(val)
        print(f"  [{label}] epoch {ep + 1:02d}/{epochs}  train loss {tl:.4f} acc {ta:.2f}%  "
              f"| val loss {v['loss']:.4f} acc {v['top1']:.2f}%  lr {sched.get_last_lr()[0]:.5f}")
    return hist


def save_results(results, filepath):
    def conv(o):
        if isinstance(o, dict):
            return {str(k): conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        if torch.is_tensor(o):
            return o.tolist()
        return o
    with open(filepath, "w") as f:
        json.dump(conv(results), f, indent=2)


def load_results(filepath):
    with open(filepath) as f:
        return json.load(f)

def print_eval_table(metrics_dict, label="Evaluation"):
    """Pretty-print a dict of metric_name -> value as a table."""
    print(f"\n  {label}")
    print(f"  {'─' * 40}")
    for name, val in metrics_dict.items():
        if isinstance(val, float):
            print(f"  {name:<25s} {val:>10.2f}")
        else:
            print(f"  {name:<25s} {str(val):>10s}")
    print(f"  {'─' * 40}")
