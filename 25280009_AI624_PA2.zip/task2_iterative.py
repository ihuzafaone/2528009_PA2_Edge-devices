"""
Task 2: Saliency-Based Iterative Pruning
Uses RANDOMLY INITIALIZED ResNet-18 (NOT pretrained).
Both iterative magnitude and GraSP start from identical random weights.
"""
import os
import sys
import copy
import time
import json
import numpy as np
import torch
import torch.nn as nn
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import OrderedDict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from utils import (
    DEVICE, BATCH_SIZE, TARGET_SPARSITY, ASSETS,
    load_random_resnet18, get_dataloaders, get_eligible_layers,
    evaluate, full_eval, profile_model, compute_sparsity, verify_masks,
    save_coo, to_coo_inference_model, apply_masks,
    train_one_epoch, save_results, load_results, get_model_size_mb
)

os.makedirs(ASSETS, exist_ok=True)

SEED = 42
TOTAL_EPOCHS = 100
FT_LR = 0.1
FT_MOMENTUM = 0.9
FT_WEIGHT_DECAY = 5e-4

# Pruning stages: at ~20%, ~40%, ~60% accuracy
STAGE_TARGETS = [0.50, 0.75, 1.00]  # fraction of TARGET_SPARSITY
ACCURACY_MILESTONES = [20.0, 40.0, 60.0]

# ─── Step 2.1: Initialize and Warm Up ────────────────────────────────
def initialize_model(device=DEVICE):
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)
    np.random.seed(SEED)
    model = load_random_resnet18(device)
    return model

def warmup_train(model, train_loader, test_loader, device=DEVICE,
                 target_acc=20.0, max_epochs=30):
    """Train until ~target_acc% accuracy is reached."""
    optimizer = torch.optim.SGD(model.parameters(), lr=FT_LR,
                                momentum=FT_MOMENTUM, weight_decay=FT_WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=TOTAL_EPOCHS)
    criterion = nn.CrossEntropyLoss()

    history = {"train_loss": [], "train_acc": [], "val_acc": [], "val_loss": []}
    warmup_epoch = 0

    for epoch in range(max_epochs):
        train_loss, train_acc = train_one_epoch(model, train_loader, optimizer,
                                                 criterion, device)
        scheduler.step()
        val_metrics = evaluate(model, test_loader, device)
        val_acc = val_metrics["top1"]

        # Compute val loss
        model.eval()
        val_loss_total = 0.0
        val_total = 0
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to(device), labels.to(device)
                loss = criterion(model(images), labels)
                val_loss_total += loss.item() * labels.size(0)
                val_total += labels.size(0)
        val_loss = val_loss_total / val_total

        history["train_loss"].append(train_loss)
        history["train_acc"].append(train_acc)
        history["val_acc"].append(val_acc)
        history["val_loss"].append(val_loss)

        print(f"  Warmup Epoch {epoch+1}: Train Acc={train_acc:.2f}%, "
              f"Val Acc={val_acc:.2f}%, Train Loss={train_loss:.4f}")

        if val_acc >= target_acc:
            warmup_epoch = epoch + 1
            print(f"  Reached ~{target_acc}% accuracy at epoch {warmup_epoch}")
            break
        warmup_epoch = epoch + 1

    return optimizer, scheduler, criterion, history, warmup_epoch

# ─── Step 2.2: Calibration Set ───────────────────────────────────────
def get_calibration_loader(data_dir="./data", num_samples=256, batch_size=128):
    """Select a small calibration subset."""
    import torchvision
    from torch.utils.data import Subset, DataLoader
    from utils import get_test_transform

    dataset = torchvision.datasets.CIFAR10(
        root=data_dir, train=True, download=False, transform=get_test_transform()
    )
    indices = torch.randperm(len(dataset))[:num_samples].tolist()
    subset = Subset(dataset, indices)
    loader = DataLoader(subset, batch_size=batch_size, shuffle=False, num_workers=2)
    print(f"  Calibration set: {num_samples} samples, batch_size={batch_size}, "
          f"num_batches={len(loader)}")
    return loader

# ─── Step 2.3: Compute GraSP Scores ──────────────────────────────────
def compute_grasp_scores(model, calibration_loader, device=DEVICE):
    """
    Compute GraSP saliency scores: S_i = -θ_i * (Hg)_i
    Following Algorithm 1 from the GraSP paper.
    """
    model.eval()
    criterion = nn.CrossEntropyLoss()

    # Identify eligible parameters (conv and linear weights only)
    eligible_params = []
    eligible_names = []
    for name, module in model.named_modules():
        if isinstance(module, (nn.Conv2d, nn.Linear)):
            eligible_params.append(module.weight)
            eligible_names.append(name)

    # Ensure gradients are enabled
    for p in eligible_params:
        p.requires_grad_(True)

    # Step 1: Compute gradient g = ∇_θ L(θ)
    model.zero_grad()
    total_loss = 0.0
    num_batches = 0
    for images, labels in calibration_loader:
        images, labels = images.to(device), labels.to(device)
        output = model(images)
        loss = criterion(output, labels)
        total_loss += loss
        num_batches += 1
    total_loss = total_loss / num_batches

    # First backward: compute gradient g
    grads = torch.autograd.grad(total_loss, eligible_params, create_graph=True)

    # Step 2: Compute Hessian-gradient product
    # z = g · g (dot product)
    z = sum((g * g).sum() for g in grads)

    # Hg = ∇_θ(g^T g) / 2
    Hg = torch.autograd.grad(z, eligible_params)

    # Step 3: Compute scores S_i = -θ_i * (Hg)_i
    scores = {}
    for name, param, hg in zip(eligible_names, eligible_params, Hg):
        score = -(param.data * hg.data)
        scores[name] = score

    model.zero_grad()
    return scores

# ─── Step 2.4 & 2.5: Iterative Pruning ───────────────────────────────
def apply_iterative_pruning(model, cumulative_masks, target_sparsity, method="magnitude",
                            calibration_loader=None, device=DEVICE):
    """
    Prune to target_sparsity using either magnitude or GraSP criterion.
    Updates cumulative_masks in-place.
    """
    eligible = get_eligible_layers(model)
    t0 = time.perf_counter()

    if method == "grasp":
        scores = compute_grasp_scores(model, calibration_loader, device)
    
    # Collect info about all eligible weights
    layer_info = []
    for name, module in eligible:
        w = module.weight.data
        already_pruned = cumulative_masks.get(name, None)
        layer_info.append((name, module, w, already_pruned))

    # Compute total params and how many need to be pruned
    total_params = sum(m.weight.numel() for _, m in eligible)
    target_pruned = int(total_params * target_sparsity)

    if method == "magnitude":
        # Collect magnitudes of currently-unpruned weights
        all_mags = []
        all_indices = []  # (layer_idx, flat_idx)
        for idx, (name, module, w, mask) in enumerate(layer_info):
            mags = w.abs().view(-1)
            if mask is not None:
                # Already-pruned weights: set to inf so they sort to the top (won't be re-pruned)
                mags = mags.clone()
                mags[mask.view(-1) == 0] = float('inf')
            all_mags.append(mags)
        all_mags_cat = torch.cat(all_mags)
        
        # Count already pruned
        already_pruned_count = (all_mags_cat == float('inf')).sum().item()
        remaining_to_prune = target_pruned - already_pruned_count
        
        if remaining_to_prune > 0:
            # Get the finite magnitudes and find threshold
            finite_mags = all_mags_cat[all_mags_cat != float('inf')]
            sorted_mags, _ = finite_mags.sort()
            threshold_idx = min(remaining_to_prune - 1, len(sorted_mags) - 1)
            threshold = sorted_mags[threshold_idx].item()
        else:
            threshold = -1.0  # Nothing more to prune

        # Apply masks
        for name, module, w, old_mask in layer_info:
            new_mask = (w.abs() > threshold).float()
            if old_mask is not None:
                new_mask = old_mask * new_mask  # Cumulative
            cumulative_masks[name] = new_mask
            module.weight.data.mul_(new_mask)
    
    else:  # grasp
        # Collect GraSP scores for unpruned weights
        all_scores = []
        for name, module, w, mask in layer_info:
            s = scores[name].view(-1).clone()
            if mask is not None:
                # Already-pruned: set to +inf so they sort to the top (won't be re-pruned)
                s[mask.view(-1) == 0] = float('inf')
            all_scores.append(s)
        all_scores_cat = torch.cat(all_scores)
        
        already_pruned_count = (all_scores_cat == float('inf')).sum().item()
        remaining_to_prune = target_pruned - already_pruned_count
        
        if remaining_to_prune > 0:
            finite_scores = all_scores_cat[all_scores_cat != float('inf')]
            # GraSP: LOWER scores -> prune first
            sorted_scores, _ = finite_scores.sort()
            threshold_idx = min(remaining_to_prune - 1, len(sorted_scores) - 1)
            threshold = sorted_scores[threshold_idx].item()
        else:
            threshold = float('-inf')
        
        # Apply masks
        offset = 0
        for name, module, w, old_mask in layer_info:
            s = scores[name].view(-1)
            size = w.numel()
            new_mask = (s > threshold).float().view(w.shape)
            if old_mask is not None:
                new_mask = old_mask * new_mask
            cumulative_masks[name] = new_mask
            module.weight.data.mul_(new_mask)
            offset += size

    t1 = time.perf_counter()
    criterion_time = t1 - t0

    overall, layer_sp = compute_sparsity(model)
    print(f"  After pruning ({method}): overall sparsity = {overall*100:.2f}%")

    return cumulative_masks, criterion_time

def train_with_pruning(model, cumulative_masks, train_loader, test_loader,
                       optimizer, scheduler, criterion, device,
                       start_epoch, total_epochs, method="magnitude",
                       calibration_loader=None, accuracy_milestones=ACCURACY_MILESTONES,
                       stage_targets=STAGE_TARGETS, target_sparsity=TARGET_SPARSITY):
    """
    Train with iterative pruning at accuracy milestones.
    """
    history = {"train_loss": [], "train_acc": [], "val_acc": [], "val_loss": []}
    stage_results = []
    current_stage = 0
    criterion_times = []

    for epoch in range(start_epoch, total_epochs):
        # Check if we should prune at this point
        if current_stage < len(accuracy_milestones):
            val_metrics = evaluate(model, test_loader, device)
            current_acc = val_metrics["top1"]

            if current_acc >= accuracy_milestones[current_stage]:
                stage_sparsity = stage_targets[current_stage] * target_sparsity
                print(f"\n  >>> PRUNING STAGE {current_stage + 1}: "
                      f"accuracy={current_acc:.2f}% >= {accuracy_milestones[current_stage]}%, "
                      f"pruning to {stage_sparsity*100:.1f}% sparsity")

                pre_metrics = evaluate(model, test_loader, device)
                cumulative_masks, ct = apply_iterative_pruning(
                    model, cumulative_masks, stage_sparsity, method,
                    calibration_loader, device
                )
                criterion_times.append(ct)
                post_metrics = evaluate(model, test_loader, device)

                stage_results.append({
                    "stage": current_stage + 1,
                    "epoch": epoch,
                    "target_sparsity": stage_sparsity,
                    "acc_before": pre_metrics["top1"],
                    "acc_after": post_metrics["top1"],
                    "criterion_time": ct,
                })
                print(f"  Acc before: {pre_metrics['top1']:.2f}%, "
                      f"Acc after: {post_metrics['top1']:.2f}%")
                current_stage += 1

        # Train one epoch with mask reapplication
        train_loss, train_acc = train_one_epoch(
            model, train_loader, optimizer, criterion, device, cumulative_masks
        )
        scheduler.step()

        # Validate
        model.eval()
        val_loss_total = 0.0
        val_total = 0
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to(device), labels.to(device)
                loss = criterion(model(images), labels)
                val_loss_total += loss.item() * labels.size(0)
                val_total += labels.size(0)
        val_loss = val_loss_total / val_total
        val_metrics = evaluate(model, test_loader, device)
        val_acc = val_metrics["top1"]

        history["train_loss"].append(train_loss)
        history["train_acc"].append(train_acc)
        history["val_acc"].append(val_acc)
        history["val_loss"].append(val_loss)

        print(f"  Epoch {epoch+1}/{total_epochs}: Train Acc={train_acc:.2f}%, "
              f"Val Acc={val_acc:.2f}%, Loss={train_loss:.4f}")

    return history, stage_results, cumulative_masks, criterion_times

# ─── Plotting ─────────────────────────────────────────────────────────
def plot_task2_curves(hist_mag, hist_grasp, warmup_hist,
                      save_loss=os.path.join(ASSETS, "task2_training_curves.png"),
                      save_acc=os.path.join(ASSETS, "task2_accuracy_curves.png")):
    # Combine warmup + training histories
    mag_loss = warmup_hist["train_loss"] + hist_mag["train_loss"]
    mag_vacc = warmup_hist["val_acc"] + hist_mag["val_acc"]
    grasp_loss = warmup_hist["train_loss"] + hist_grasp["train_loss"]
    grasp_vacc = warmup_hist["val_acc"] + hist_grasp["val_acc"]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    axes[0].plot(mag_loss, label="Iter. Magnitude Train Loss")
    axes[0].plot(grasp_loss, label="Iter. GraSP Train Loss")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Loss")
    axes[0].set_title("Training Loss")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    mag_vloss = warmup_hist["val_loss"] + hist_mag["val_loss"]
    grasp_vloss = warmup_hist["val_loss"] + hist_grasp["val_loss"]
    axes[1].plot(mag_vloss, label="Iter. Magnitude Val Loss")
    axes[1].plot(grasp_vloss, label="Iter. GraSP Val Loss")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].set_title("Validation Loss")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_loss, dpi=150, bbox_inches='tight')
    plt.close()

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(mag_vacc, label="Iter. Magnitude Val Acc")
    ax.plot(grasp_vacc, label="Iter. GraSP Val Acc")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("Validation Accuracy Curves")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_acc, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Plots saved to {save_loss} and {save_acc}")

def plot_layer_remaining(model_mag, model_grasp,
                         save_path=os.path.join(ASSETS, "layer_wise_sparsity.png")):
    _, mag_sp = compute_sparsity(model_mag)
    _, grasp_sp = compute_sparsity(model_grasp)

    names = list(mag_sp.keys())
    short_names = [n.replace('layer', 'L').replace('.weight', '').replace('.', '/') for n in names]
    mag_remaining = [(1 - mag_sp[n]) * 100 for n in names]
    grasp_remaining = [(1 - grasp_sp[n]) * 100 for n in names]

    x = np.arange(len(names))
    width = 0.35
    fig, ax = plt.subplots(figsize=(14, 6))
    ax.bar(x - width/2, mag_remaining, width, label='Iter. Magnitude', alpha=0.8)
    ax.bar(x + width/2, grasp_remaining, width, label='Iter. GraSP', alpha=0.8)
    ax.set_xlabel("Layer")
    ax.set_ylabel("Remaining Weights (%)")
    ax.set_title("Layer-wise Remaining Weight Ratio")
    ax.set_xticks(x)
    ax.set_xticklabels(short_names, rotation=45, ha='right', fontsize=7)
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Layer-wise sparsity plot saved to {save_path}")

# ─── Main ─────────────────────────────────────────────────────────────
def run_task2(data_dir="./data", run_training=False):
    print("\n" + "=" * 60)
    print("  TASK 2: Saliency-Based Iterative Pruning")
    print("=" * 60)
    print(f"  Target sparsity: {TARGET_SPARSITY*100:.0f}%")
    print(f"  Using RANDOM initialization (NOT pretrained)")
    print(f"  Seed: {SEED}")

    loaders = get_dataloaders(data_dir)
    train_loader = loaders["train"]
    test_loader = loaders["val"]        # use val split for milestone decisions (never test)
    train_eval_loader = loaders["train_eval"]
    test_eval_loader = loaders["test"]

    if not run_training:
        print("\n  Task 2 requires training from scratch.")
        print("  Run with run_training=True to execute.")
        print("  This will:")
        print("    1. Initialize random ResNet-18")
        print("    2. Warm up to ~20% accuracy")
        print("    3. Run iterative magnitude pruning")
        print("    4. Run iterative GraSP pruning (from same init)")
        print("    5. Profile and compare both")
        return None

    # Step 2.1: Initialize
    print("\n[Step 2.1] Initializing random ResNet-18...")
    model_init = initialize_model(DEVICE)
    torch.save(model_init.state_dict(), os.path.join(ASSETS, "task2_initial_weights.pt"))

    # Step 2.2: Calibration set
    print("\n[Step 2.2] Preparing calibration set...")
    cal_loader = get_calibration_loader(data_dir)

    # ─── Branch 1: Iterative Magnitude Pruning ────────────────────
    print("\n" + "=" * 50)
    print("  Branch 1: Iterative Magnitude Pruning")
    print("=" * 50)

    model_mag = initialize_model(DEVICE)
    model_mag.load_state_dict(torch.load(os.path.join(ASSETS, "task2_initial_weights.pt"),
                                          map_location=DEVICE))

    print("\n  Warming up...")
    opt_mag, sched_mag, crit_mag, warmup_hist_mag, warmup_ep = warmup_train(
        model_mag, train_loader, test_loader, DEVICE, target_acc=20.0
    )
    torch.save({
        'model_state_dict': model_mag.state_dict(),
        'optimizer': opt_mag.state_dict(),
        'scheduler': sched_mag.state_dict(),
        'warmup_epoch': warmup_ep,
        'warmup_history': warmup_hist_mag,
    }, os.path.join(ASSETS, "task2_warmup_mag.pt"))

    print("\n  Training with iterative magnitude pruning...")
    mag_masks = {}
    hist_mag, stages_mag, mag_masks, mag_times = train_with_pruning(
        model_mag, mag_masks, train_loader, test_loader,
        opt_mag, sched_mag, crit_mag, DEVICE,
        start_epoch=warmup_ep, total_epochs=TOTAL_EPOCHS,
        method="magnitude", calibration_loader=cal_loader
    )

    torch.save({
        'model_state_dict': model_mag.state_dict(),
        'masks': mag_masks,
        'history': hist_mag,
        'stages': stages_mag,
        'warmup_history': warmup_hist_mag,
    }, os.path.join(ASSETS, "task2_magnitude_final.pt"))

    # ─── Branch 2: Iterative GraSP Pruning ────────────────────────
    print("\n" + "=" * 50)
    print("  Branch 2: Iterative GraSP Pruning")
    print("=" * 50)

    model_grasp = initialize_model(DEVICE)
    model_grasp.load_state_dict(torch.load(os.path.join(ASSETS, "task2_initial_weights.pt"),
                                            map_location=DEVICE))

    print("\n  Warming up...")
    opt_grasp, sched_grasp, crit_grasp, warmup_hist_grasp, warmup_ep2 = warmup_train(
        model_grasp, train_loader, test_loader, DEVICE, target_acc=20.0
    )
    torch.save({
        'model_state_dict': model_grasp.state_dict(),
        'optimizer': opt_grasp.state_dict(),
        'scheduler': sched_grasp.state_dict(),
        'warmup_epoch': warmup_ep2,
        'warmup_history': warmup_hist_grasp,
    }, os.path.join(ASSETS, "task2_warmup_grasp.pt"))

    print("\n  Training with iterative GraSP pruning...")
    grasp_masks = {}
    hist_grasp, stages_grasp, grasp_masks, grasp_times = train_with_pruning(
        model_grasp, grasp_masks, train_loader, test_loader,
        opt_grasp, sched_grasp, crit_grasp, DEVICE,
        start_epoch=warmup_ep2, total_epochs=TOTAL_EPOCHS,
        method="grasp", calibration_loader=cal_loader
    )

    torch.save({
        'model_state_dict': model_grasp.state_dict(),
        'masks': grasp_masks,
        'history': hist_grasp,
        'stages': stages_grasp,
        'warmup_history': warmup_hist_grasp,
    }, os.path.join(ASSETS, "task2_grasp_final.pt"))

    # ─── Step 2.7: Profile Final Models ───────────────────────────
    print("\n[Step 2.7] Profiling final models...")

    # Verify masks
    print("\n  Verifying magnitude model masks:")
    verify_masks(model_mag, mag_masks)
    print("\n  Verifying GraSP model masks:")
    verify_masks(model_grasp, grasp_masks)

    # COO conversion
    coo_mag = save_coo(model_mag, mag_masks, os.path.join(ASSETS, "task2_mag_coo"))
    coo_grasp = save_coo(model_grasp, grasp_masks, os.path.join(ASSETS, "task2_grasp_coo"))
    mag_coo_size = coo_mag["coo_int64_file_mb"]
    grasp_coo_size = coo_grasp["coo_int64_file_mb"]
    print(f"\n  Magnitude COO size: {mag_coo_size:.2f} MB")
    print(f"  GraSP COO size: {grasp_coo_size:.2f} MB")

    # Evaluate
    mag_eval_train = evaluate(model_mag, train_eval_loader, DEVICE)
    mag_eval_test = evaluate(model_mag, test_eval_loader, DEVICE)
    grasp_eval_train = evaluate(model_grasp, train_eval_loader, DEVICE)
    grasp_eval_test = evaluate(model_grasp, test_eval_loader, DEVICE)

    # Profile
    mag_profile = profile_model(model_mag, test_eval_loader, DEVICE,
                                 label="Iter. Magnitude Final")
    grasp_profile = profile_model(model_grasp, test_eval_loader, DEVICE,
                                   label="Iter. GraSP Final")

    # Plots
    plot_task2_curves(hist_mag, hist_grasp, warmup_hist_mag)
    plot_layer_remaining(model_mag, model_grasp)

    # Compile results
    results = {
        "magnitude": {
            "stages": stages_mag,
            "criterion_times": mag_times,
            **{f"train_{k}": v for k, v in mag_eval_train.items()},
            **{f"test_{k}": v for k, v in mag_eval_test.items()},
            **mag_profile,
            "coo_size_mb": mag_coo_size,
        },
        "grasp": {
            "stages": stages_grasp,
            "criterion_times": grasp_times,
            **{f"train_{k}": v for k, v in grasp_eval_train.items()},
            **{f"test_{k}": v for k, v in grasp_eval_test.items()},
            **grasp_profile,
            "coo_size_mb": grasp_coo_size,
        },
    }
    save_results(results, os.path.join(ASSETS, "task2_results.json"))
    print("\n  All Task 2 results saved.")
    return results

if __name__ == "__main__":
    run_task2(run_training=False)
