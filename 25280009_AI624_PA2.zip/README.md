# AI624 — Assignment 2: Neural Network Pruning on ResNet-18 (CIFAR-10)

**Name:** Huzaifa  
**Roll Number:** 25280009

## Dependencies

```
torch >= 2.0
torchvision
thop          # MACs / FLOPs counting
nvidia-ml-py  # GPU energy monitoring (pynvml)
scikit-learn  # LASSO (Task 3) and Macro-F1
numpy
matplotlib
```

Install all dependencies:

```bash
pip install torch torchvision thop nvidia-ml-py scikit-learn numpy matplotlib
```

## Setup

1. Clone the pretrained CIFAR-10 ResNet-18 checkpoint repository:

```bash
git clone https://github.com/huyvnphan/PyTorch_CIFAR10.git
```

2. The CIFAR-10 dataset will be automatically downloaded to `./data/` on first run.

## How to Run

Open `main.ipynb` in Jupyter and **run all cells sequentially** (top to bottom):

```bash
jupyter notebook main.ipynb
```

Estimated runtime: ~90 minutes on an NVIDIA RTX 4060 Laptop GPU.

Alternatively, execute via command line:

```bash
jupyter nbconvert --to notebook --execute --ExecutePreprocessor.timeout=7200 main.ipynb --output main_executed.ipynb
```

## Codebase Outline

| File | Description |
|------|-------------|
| `main.ipynb` | Main notebook — runs all 4 tasks sequentially with inline outputs and plots |
| `utils.py` | Shared helpers: data loading, evaluation, profiling (latency, memory, energy), COO conversion, model loading |
| `task0_baseline.py` | **Task 0:** Load pretrained ResNet-18, evaluate (Top-1/5, Macro-F1), full profiling |
| `task1_unstructured.py` | **Task 1:** Layer-wise sensitivity analysis, local/global magnitude pruning, fine-tuning with mask enforcement, COO storage |
| `task2_iterative.py` | **Task 2:** Iterative pruning from random init — magnitude and GraSP saliency, cumulative masks, milestone-based schedule |
| `task3_structured.py` | **Task 3:** Regression-based structured channel pruning (He et al., 2017) — LASSO selection, least-squares reconstruction, BN/shortcut updates |
| `REPORT.md` | Detailed written report with analysis, tables, and discussion |
| `report_assets/` | All saved plots (`.png`), result JSONs (`.json`), and model checkpoints (`.pt`) |

## Tasks Overview

| Task | Method | Target Sparsity |
|------|--------|----------------|
| 0 | Baseline profiling | 0% (dense) |
| 1 | Unstructured post-training magnitude pruning (local + global) | 80% |
| 2 | Saliency-based iterative pruning (magnitude + GraSP) from scratch | 80% |
| 3 | Structured regression-based channel pruning | ~66% parameter reduction |
